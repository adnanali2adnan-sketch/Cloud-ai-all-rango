# Add project specific ProGuard rules here.
-keep class com.rangocompanion.** { *; }
-keep class com.google.mlkit.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
