package com.rangocompanion.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val MODEL = "gemini-1.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    suspend fun analyzeRounds(
        apiKey: String,
        multipliers: List<Double>,
        balance: Double,
        trendLabel: String,
        nextPred: Double,
        cashoutAt: Double
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "API key not set. Go to Gemini AI tab."

        val recentStr = multipliers.take(10).joinToString(", ") { "${it}x" }
        val prompt = """
You are a crash game strategy advisor for Rango/Aviator.

Recent multipliers (newest first): $recentStr
Current balance: PKR $balance
Local trend engine says: $trendLabel
Predicted next round: ${nextPred}x
Suggested cashout: ${cashoutAt}x

Give me a SHORT 2-sentence analysis:
1. Confirm or challenge the trend
2. Your recommended cashout point and bet size (as % of balance)

Be direct. No disclaimers. Max 40 words total.
        """.trimIndent()

        try {
            val json = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                    put("maxOutputTokens", 100)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext "No response from Gemini."

            if (!response.isSuccessful) {
                return@withContext "Gemini error: ${response.code}. Check your API key."
            }

            val jsonResp = JSONObject(body)
            val text = jsonResp
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            text.trim()
        } catch (e: Exception) {
            "Network error: ${e.message}"
        }
    }

    suspend fun getHudTip(
        apiKey: String,
        multipliers: List<Double>,
        trendLabel: String,
        cashoutAt: Double
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "Set API key in app."

        val recentStr = multipliers.take(5).joinToString(", ") { "${it}x" }
        val prompt = """
Crash game HUD tip. Recent: $recentStr. Trend: $trendLabel.
Give ONE action sentence under 12 words. Example: "Cashout at 1.3x, trend falling."
        """.trimIndent()

        try {
            val json = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.2)
                    put("maxOutputTokens", 30)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext "No response."

            if (!response.isSuccessful) return@withContext "API error ${response.code}"

            JSONObject(body)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()
        } catch (e: Exception) {
            "Cashout at ${cashoutAt}x — stay safe."
        }
    }
}
