package com.rangocompanion.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.rangocompanion.api.GeminiApiClient
import com.rangocompanion.data.AppDatabase
import com.rangocompanion.data.RoundEntity
import com.rangocompanion.util.BankrollAdvice
import com.rangocompanion.util.BankrollManager
import com.rangocompanion.util.TrendAnalyzer
import com.rangocompanion.util.TrendResult
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.roundDao()

    // Encrypted prefs for API key
    private val masterKey = MasterKey.Builder(application)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs = EncryptedSharedPreferences.create(
        application,
        "rango_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val normalPrefs = application.getSharedPreferences("rango_prefs", Context.MODE_PRIVATE)

    // LiveData
    private val _rounds = MutableLiveData<List<RoundEntity>>(emptyList())
    val rounds: LiveData<List<RoundEntity>> = _rounds

    private val _trendResult = MutableLiveData<TrendResult>()
    val trendResult: LiveData<TrendResult> = _trendResult

    private val _bankrollAdvice = MutableLiveData<BankrollAdvice>()
    val bankrollAdvice: LiveData<BankrollAdvice> = _bankrollAdvice

    private val _geminiResponse = MutableLiveData<String>("")
    val geminiResponse: LiveData<String> = _geminiResponse

    private val _isGeminiLoading = MutableLiveData<Boolean>(false)
    val isGeminiLoading: LiveData<Boolean> = _isGeminiLoading

    private val _balance = MutableLiveData<Double>(0.0)
    val balance: LiveData<Double> = _balance

    // OCR Status
    private val _ocrStatus = MutableLiveData<String>("OCR offline")
    val ocrStatus: LiveData<String> = _ocrStatus

    private val _lastOcrMultiplier = MutableLiveData<Double?>(null)
    val lastOcrMultiplier: LiveData<Double?> = _lastOcrMultiplier

    init {
        // Load balance
        _balance.value = normalPrefs.getFloat("balance", 0f).toDouble()

        // Observe rounds from DB
        viewModelScope.launch {
            dao.getAllRounds().collectLatest { list ->
                _rounds.value = list
                val mults = list.map { it.multiplier }
                if (mults.isNotEmpty()) {
                    val trend = TrendAnalyzer.analyze(mults)
                    _trendResult.value = trend
                    val bal = _balance.value ?: 0.0
                    _bankrollAdvice.value = BankrollManager.calculate(bal, trend)
                }
            }
        }
    }

    fun addRound(multiplier: Double, source: String = "MANUAL") {
        viewModelScope.launch {
            dao.insertRound(RoundEntity(multiplier = multiplier, source = source))
            // Auto-trigger Gemini analysis after OCR round
            if (source == "OCR") {
                val apiKey = getApiKey()
                if (apiKey.isNotBlank()) {
                    requestGeminiAnalysis()
                }
            }
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            dao.clearAll()
            _trendResult.value = null
            _geminiResponse.value = "Rounds cleared."
        }
    }

    fun updateBalance(amount: Double) {
        _balance.value = amount
        normalPrefs.edit().putFloat("balance", amount.toFloat()).apply()
        // Recalculate bankroll
        val trend = _trendResult.value ?: return
        _bankrollAdvice.value = BankrollManager.calculate(amount, trend)
    }

    fun saveApiKey(key: String) {
        securePrefs.edit().putString("gemini_api_key", key).apply()
    }

    fun getApiKey(): String {
        return securePrefs.getString("gemini_api_key", "") ?: ""
    }

    fun requestGeminiAnalysis() {
        val mults = _rounds.value?.map { it.multiplier } ?: return
        if (mults.isEmpty()) {
            _geminiResponse.value = "Rounds add karo → auto analysis shuru ho"
            return
        }
        val trend = _trendResult.value ?: return
        val bal = _balance.value ?: 0.0

        viewModelScope.launch {
            _isGeminiLoading.value = true
            val response = GeminiApiClient.analyzeRounds(
                apiKey = getApiKey(),
                multipliers = mults,
                balance = bal,
                trendLabel = trend.trendLabel,
                nextPred = trend.nextPred,
                cashoutAt = trend.cashoutAt
            )
            _geminiResponse.value = response
            _isGeminiLoading.value = false
        }
    }

    fun onOcrMultiplierDetected(multiplier: Double) {
        _lastOcrMultiplier.value = multiplier
        _ocrStatus.value = "CRASH DETECTED: ${multiplier}x"
        addRound(multiplier, "OCR")
    }

    fun setOcrStatus(status: String) {
        _ocrStatus.value = status
    }
}
