package com.rangocompanion

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.rangocompanion.service.FloatingHudService
import com.rangocompanion.service.OcrCaptureService
import com.rangocompanion.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: MainViewModel
    private var projMgr: MediaProjectionManager? = null
    private var ocrReceiver: BroadcastReceiver? = null
    private var hudManualReceiver: BroadcastReceiver? = null
    private var hudOcrToggleReceiver: BroadcastReceiver? = null
    private var isHudActive = false
    private var isOcrActive = false

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) startOcrService(result.resultCode, result.data!!)
        else { Toast.makeText(this, "Screen capture denied", Toast.LENGTH_SHORT).show(); viewModel.setOcrStatus("OCR offline.") }
    }

    private val overlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(this)) startHudService()
        else Toast.makeText(this, "Overlay permission required!", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        projMgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        setupNav()
        setupOcrReceiver()
        setupHudReceivers()
        setupObservers()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
    }

    private fun setupNav() {
        val nav = (supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment).navController
        findViewById<BottomNavigationView>(R.id.bottom_navigation).setupWithNavController(nav)
    }

    private fun setupOcrReceiver() {
        ocrReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val m = intent?.getDoubleExtra(OcrCaptureService.EXTRA_MULTIPLIER, 0.0) ?: return
                if (m > 0) { viewModel.onOcrMultiplierDetected(m); Handler(Looper.getMainLooper()).postDelayed({ updateHud() }, 400) }
            }
        }
        reg(ocrReceiver!!, OcrCaptureService.BROADCAST_OCR_RESULT, false)
    }

    private fun setupHudReceivers() {
        // Manual entry from HUD
        hudManualReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val m = intent?.getDoubleExtra(FloatingHudService.EXTRA_MULTIPLIER, 0.0) ?: return
                if (m >= 1.0) {
                    viewModel.addRound(m, "MANUAL")
                    Handler(Looper.getMainLooper()).postDelayed({ updateHud() }, 500)
                }
            }
        }
        reg(hudManualReceiver!!, FloatingHudService.BROADCAST_MANUAL_MULT, true)

        // OCR toggle from HUD
        hudOcrToggleReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (isOcrActive) stopOcr() else startOcr()
            }
        }
        reg(hudOcrToggleReceiver!!, FloatingHudService.BROADCAST_OCR_TOGGLE, true)
    }

    private fun setupObservers() {
        viewModel.trendResult.observe(this) { updateHud() }
        viewModel.geminiResponse.observe(this) { updateHud() }
        viewModel.rounds.observe(this) { updateHud() }
        viewModel.ocrStatus.observe(this) { updateHud() }
    }

    fun startHud() {
        if (!Settings.canDrawOverlays(this)) {
            overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startHudService()
    }

    private fun startHudService() {
        startForegroundService(Intent(this, FloatingHudService::class.java).apply { action = FloatingHudService.ACTION_START_HUD })
        isHudActive = true
        Toast.makeText(this, "HUD on! Tap it to expand.", Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({ updateHud() }, 300)
    }

    fun stopHud() {
        startService(Intent(this, FloatingHudService::class.java).apply { action = FloatingHudService.ACTION_STOP_HUD })
        isHudActive = false
    }

    fun startOcr() {
        projMgr?.createScreenCaptureIntent()?.let { projLauncher.launch(it) }
    }

    private fun startOcrService(resultCode: Int, data: Intent) {
        startForegroundService(Intent(this, OcrCaptureService::class.java).apply {
            action = OcrCaptureService.ACTION_START
            putExtra(OcrCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(OcrCaptureService.EXTRA_RESULT_DATA, data)
        })
        isOcrActive = true
        viewModel.setOcrStatus("AUTO OCR active — scanning...")
        Toast.makeText(this, "OCR started! Switch to Rango.", Toast.LENGTH_LONG).show()
        updateHud()
    }

    fun stopOcr() {
        startService(Intent(this, OcrCaptureService::class.java).apply { action = OcrCaptureService.ACTION_STOP })
        isOcrActive = false
        viewModel.setOcrStatus("OCR stopped.")
        updateHud()
    }

    fun isOcrRunning() = isOcrActive
    fun isHudRunning() = isHudActive

    fun updateHud() {
        if (!isHudActive) return
        val trend = viewModel.trendResult.value ?: return
        val rounds = viewModel.rounds.value ?: return
        val lastMult = rounds.firstOrNull()?.multiplier ?: 0.0
        startService(Intent(this, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_UPDATE_HUD
            putExtra(FloatingHudService.EXTRA_TREND, trend.trendLabel)
            putExtra(FloatingHudService.EXTRA_CASHOUT, trend.cashoutAt)
            putExtra(FloatingHudService.EXTRA_NEXT, trend.nextPred)
            putExtra(FloatingHudService.EXTRA_MIN_SAFE, trend.minSafe)
            putExtra(FloatingHudService.EXTRA_BET_MULT, "${trend.betMultiplier}x")
            putExtra(FloatingHudService.EXTRA_LAST_MULT, lastMult)
            putExtra(FloatingHudService.EXTRA_DIRECTION, trend.trendDirection)
            putExtra(FloatingHudService.EXTRA_STREAK, trend.streakLabel)
            putExtra(FloatingHudService.EXTRA_ADVICE, trend.advice)
            putExtra(FloatingHudService.EXTRA_AI_TIP, viewModel.geminiResponse.value ?: "")
            putExtra(FloatingHudService.EXTRA_RISK, trend.riskLevel)
            putExtra(FloatingHudService.EXTRA_OCR_STATUS, viewModel.ocrStatus.value ?: "")
            putExtra(FloatingHudService.EXTRA_OCR_RUNNING, isOcrActive)
        })
    }

    private fun reg(r: BroadcastReceiver, action: String, exported: Boolean) {
        val f = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(r, f, if (exported) Context.RECEIVER_EXPORTED else Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(r, f)
    }

    override fun onDestroy() {
        ocrReceiver?.let { unregisterReceiver(it) }
        hudManualReceiver?.let { unregisterReceiver(it) }
        hudOcrToggleReceiver?.let { unregisterReceiver(it) }
        super.onDestroy()
    }
}
