package com.rangocompanion

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.rangocompanion.service.FloatingHudService
import com.rangocompanion.service.OcrCaptureService
import com.rangocompanion.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: MainViewModel
    private var mediaProjectionManager: MediaProjectionManager? = null
    private var ocrReceiver: BroadcastReceiver? = null
    private var hudManualReceiver: BroadcastReceiver? = null
    private var isHudActive = false
    private var isOcrActive = false

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startOcrService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture denied", Toast.LENGTH_SHORT).show()
            viewModel.setOcrStatus("OCR offline. Press AUTH OCR.")
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) startHudService()
        else Toast.makeText(this, "Overlay permission required!", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        setupNavigation()
        setupOcrReceiver()
        setupHudManualReceiver()
        setupHudObservers()
        requestNotificationPermission()
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        findViewById<BottomNavigationView>(R.id.bottom_navigation)
            .setupWithNavController(navController)
    }

    // OCR broadcast receiver
    private fun setupOcrReceiver() {
        ocrReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val multiplier = intent?.getDoubleExtra(OcrCaptureService.EXTRA_MULTIPLIER, 0.0) ?: return
                if (multiplier > 0) {
                    viewModel.onOcrMultiplierDetected(multiplier)
                    updateHudWithLatestData()
                }
            }
        }
        val filter = IntentFilter(OcrCaptureService.BROADCAST_OCR_RESULT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(ocrReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(ocrReceiver, filter)
        }
    }

    // HUD manual multiplier entry broadcast
    private fun setupHudManualReceiver() {
        hudManualReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val mult = intent?.getDoubleExtra(FloatingHudService.EXTRA_MULTIPLIER, 0.0) ?: return
                if (mult >= 1.0) {
                    viewModel.addRound(mult, "MANUAL")
                    Toast.makeText(this@MainActivity, "${mult}x logged from HUD!", Toast.LENGTH_SHORT).show()
                    // Update HUD after adding
                    android.os.Handler(mainLooper).postDelayed({ updateHudWithLatestData() }, 500)
                }
            }
        }
        val filter = IntentFilter(FloatingHudService.BROADCAST_MANUAL_MULT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(hudManualReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(hudManualReceiver, filter)
        }
    }

    // Auto-update HUD when data changes
    private fun setupHudObservers() {
        viewModel.trendResult.observe(this) { updateHudWithLatestData() }
        viewModel.geminiResponse.observe(this) { updateHudWithLatestData() }
        viewModel.rounds.observe(this) { updateHudWithLatestData() }
    }

    fun startHud() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            overlayPermissionLauncher.launch(intent)
            return
        }
        startHudService()
    }

    private fun startHudService() {
        val intent = Intent(this, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_START_HUD
        }
        startForegroundService(intent)
        isHudActive = true
        Toast.makeText(this, "HUD activated! Tap it to expand predictions.", Toast.LENGTH_LONG).show()
        android.os.Handler(mainLooper).postDelayed({ updateHudWithLatestData() }, 300)
    }

    fun stopHud() {
        val intent = Intent(this, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_STOP_HUD
        }
        startService(intent)
        isHudActive = false
    }

    fun startOcr() {
        val intent = mediaProjectionManager?.createScreenCaptureIntent()
        if (intent != null) mediaProjectionLauncher.launch(intent)
    }

    private fun startOcrService(resultCode: Int, resultData: Intent) {
        val intent = Intent(this, OcrCaptureService::class.java).apply {
            action = OcrCaptureService.ACTION_START
            putExtra(OcrCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(OcrCaptureService.EXTRA_RESULT_DATA, resultData)
        }
        startForegroundService(intent)
        isOcrActive = true
        viewModel.setOcrStatus("AUTO OCR active — scanning...")
        Toast.makeText(this, "OCR started! Switch to Rango game now.", Toast.LENGTH_LONG).show()
    }

    fun stopOcr() {
        val intent = Intent(this, OcrCaptureService::class.java).apply {
            action = OcrCaptureService.ACTION_STOP
        }
        startService(intent)
        isOcrActive = false
        viewModel.setOcrStatus("OCR stopped.")
    }

    fun isOcrRunning() = isOcrActive
    fun isHudRunning() = isHudActive

    fun updateHudWithLatestData() {
        if (!isHudActive) return
        val trend = viewModel.trendResult.value ?: return
        val rounds = viewModel.rounds.value ?: return
        val lastMult = rounds.firstOrNull()?.multiplier ?: 0.0
        val aiTip = viewModel.geminiResponse.value ?: ""

        val intent = Intent(this, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_UPDATE_HUD
            putExtra(FloatingHudService.EXTRA_TREND, trend.trendLabel)
            putExtra(FloatingHudService.EXTRA_CASHOUT, trend.cashoutAt)
            putExtra(FloatingHudService.EXTRA_NEXT, trend.nextPred)
            putExtra(FloatingHudService.EXTRA_MIN_SAFE, trend.minSafe)
            putExtra(FloatingHudService.EXTRA_BET_MULT, "${trend.betMultiplier}x base")
            putExtra(FloatingHudService.EXTRA_LAST_MULT, lastMult)
            putExtra(FloatingHudService.EXTRA_DIRECTION, trend.trendDirection)
            putExtra(FloatingHudService.EXTRA_STREAK, trend.streakLabel)
            putExtra(FloatingHudService.EXTRA_ADVICE, trend.advice)
            putExtra(FloatingHudService.EXTRA_AI_TIP, aiTip)
            putExtra(FloatingHudService.EXTRA_RISK, trend.riskLevel)
        }
        startService(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    override fun onDestroy() {
        ocrReceiver?.let { unregisterReceiver(it) }
        hudManualReceiver?.let { unregisterReceiver(it) }
        super.onDestroy()
    }
}
