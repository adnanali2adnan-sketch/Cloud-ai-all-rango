package com.rangocompanion.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.rangocompanion.MainActivity
import com.rangocompanion.R
import com.rangocompanion.util.TrendAnalyzer
import com.rangocompanion.viewmodel.MainViewModel
import java.text.DecimalFormat

class DashboardFragment : Fragment() {

    private lateinit var viewModel: MainViewModel
    private val df = DecimalFormat("0.00")

    // Views
    private lateinit var chipGroupMultipliers: ChipGroup
    private lateinit var tvTrendLabel: TextView
    private lateinit var tvConfidence: TextView
    private lateinit var tvNextPred: TextView
    private lateinit var tvCashoutAt: TextView
    private lateinit var tvMinSafe: TextView
    private lateinit var tvBetMult: TextView
    private lateinit var tvTrendDir: TextView
    private lateinit var tvStreak: TextView
    private lateinit var tvAdvice: TextView
    private lateinit var tvWinRate: TextView
    private lateinit var tvColdRate: TextView
    private lateinit var tvNetPL: TextView
    private lateinit var tvBalance: TextView
    private lateinit var tvRiskScore: TextView
    private lateinit var tvBaseBet: TextView
    private lateinit var tvStrategicBet: TextView
    private lateinit var tvSafeCashout: TextView
    private lateinit var tvStopLoss: TextView
    private lateinit var tvDailyTarget: TextView
    private lateinit var tvOcrStatus: TextView
    private lateinit var btnActivateHud: MaterialButton
    private lateinit var btnAuthOcr: MaterialButton
    private lateinit var btnStopOcr: MaterialButton
    private lateinit var btnClearAll: ImageButton
    private lateinit var etManualMult: EditText
    private lateinit var btnAddManual: MaterialButton

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        initViews(view)
        setupObservers()
        setupClickListeners()
    }

    private fun initViews(view: View) {
        chipGroupMultipliers = view.findViewById(R.id.chipGroupMultipliers)
        tvTrendLabel = view.findViewById(R.id.tvTrendLabel)
        tvConfidence = view.findViewById(R.id.tvConfidence)
        tvNextPred = view.findViewById(R.id.tvNextPred)
        tvCashoutAt = view.findViewById(R.id.tvCashoutAt)
        tvMinSafe = view.findViewById(R.id.tvMinSafe)
        tvBetMult = view.findViewById(R.id.tvBetMult)
        tvTrendDir = view.findViewById(R.id.tvTrendDir)
        tvStreak = view.findViewById(R.id.tvStreak)
        tvAdvice = view.findViewById(R.id.tvAdvice)
        tvWinRate = view.findViewById(R.id.tvWinRate)
        tvColdRate = view.findViewById(R.id.tvColdRate)
        tvNetPL = view.findViewById(R.id.tvNetPL)
        tvBalance = view.findViewById(R.id.tvBalance)
        tvRiskScore = view.findViewById(R.id.tvRiskScore)
        tvBaseBet = view.findViewById(R.id.tvBaseBet)
        tvStrategicBet = view.findViewById(R.id.tvStrategicBet)
        tvSafeCashout = view.findViewById(R.id.tvSafeCashout)
        tvStopLoss = view.findViewById(R.id.tvStopLoss)
        tvDailyTarget = view.findViewById(R.id.tvDailyTarget)
        tvOcrStatus = view.findViewById(R.id.tvOcrStatus)
        btnActivateHud = view.findViewById(R.id.btnActivateHud)
        btnAuthOcr = view.findViewById(R.id.btnAuthOcr)
        btnStopOcr = view.findViewById(R.id.btnStopOcr)
        btnClearAll = view.findViewById(R.id.btnClearAll)
        etManualMult = view.findViewById(R.id.etManualMult)
        btnAddManual = view.findViewById(R.id.btnAddManual)
    }

    private fun setupObservers() {
        viewModel.rounds.observe(viewLifecycleOwner) { rounds ->
            // Update multiplier chips row
            chipGroupMultipliers.removeAllViews()
            rounds.take(8).forEachIndexed { index, round ->
                val chip = Chip(requireContext()).apply {
                    text = "${df.format(round.multiplier)}x"
                    isCheckable = false
                    chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                        when {
                            round.multiplier >= 5.0 -> Color.parseColor("#6B21A8") // purple - big
                            round.multiplier >= 2.0 -> Color.parseColor("#1E3A1E") // dark green
                            round.multiplier < 1.3 -> Color.parseColor("#3A1515") // dark red
                            else -> Color.parseColor("#1A1A1A") // dark
                        }
                    )
                    setTextColor(
                        when {
                            round.multiplier >= 5.0 -> Color.parseColor("#C084FC")
                            round.multiplier >= 2.0 -> Color.parseColor("#39FF14")
                            round.multiplier < 1.3 -> Color.parseColor("#FF6B6B")
                            else -> Color.WHITE
                        }
                    )
                    if (index == 0) strokeColor = android.content.res.ColorStateList.valueOf(Color.parseColor("#FFA500"))
                }
                chipGroupMultipliers.addView(chip)
            }

            if (rounds.isEmpty()) {
                tvWinRate.text = "0%"
                tvColdRate.text = "0%"
                tvNetPL.text = "+0"
            } else {
                val mults = rounds.map { it.multiplier }
                tvWinRate.text = "${TrendAnalyzer.getWinRate(mults).toInt()}%"
                tvColdRate.text = "${TrendAnalyzer.getColdRate(mults).toInt()}%"
                val netPL = TrendAnalyzer.getNetPL(mults, viewModel.bankrollAdvice.value?.baseBet ?: 1.0, 1.5)
                tvNetPL.text = if (netPL >= 0) "+${df.format(netPL)}" else df.format(netPL)
                tvNetPL.setTextColor(if (netPL >= 0) Color.parseColor("#39FF14") else Color.RED)
            }
        }

        viewModel.trendResult.observe(viewLifecycleOwner) { trend ->
            trend ?: return@observe
            tvTrendLabel.text = "${trend.trendEmoji} ${trend.trendLabel}"
            tvConfidence.text = "${trend.confidence}%"
            tvNextPred.text = "${df.format(trend.nextPred)}x"
            tvCashoutAt.text = "${df.format(trend.cashoutAt)}x"
            tvMinSafe.text = "${df.format(trend.minSafe)}x"
            tvBetMult.text = "${trend.betMultiplier}x base"
            tvAdvice.text = trend.advice

            // Trend direction color
            tvTrendDir.text = "↓ ${trend.trendDirection}"
            tvTrendDir.setTextColor(
                when (trend.trendDirection) {
                    "FALLING" -> Color.parseColor("#FFA500")
                    "RISING" -> Color.parseColor("#39FF14")
                    else -> Color.WHITE
                }
            )

            tvStreak.text = trend.streakLabel
            tvStreak.setTextColor(
                when (trend.streakLabel) {
                    "HOT" -> Color.parseColor("#39FF14")
                    "COLD" -> Color.parseColor("#60A5FA")
                    else -> Color.WHITE
                }
            )

            // Trend label color
            tvTrendLabel.setTextColor(
                when {
                    trend.trendLabel.contains("HOT") -> Color.parseColor("#39FF14")
                    trend.trendLabel.contains("DOWN") || trend.trendLabel.contains("COLD") -> Color.parseColor("#FFA500")
                    trend.trendLabel.contains("RISING") -> Color.parseColor("#60A5FA")
                    else -> Color.WHITE
                }
            )
        }

        viewModel.bankrollAdvice.observe(viewLifecycleOwner) { advice ->
            advice ?: return@observe
            tvBalance.text = "PKR ${df.format(viewModel.balance.value ?: 0.0)}"
            tvRiskScore.text = advice.riskScore
            tvRiskScore.setTextColor(
                when (advice.riskColor) {
                    "RED" -> Color.RED
                    "ORANGE" -> Color.parseColor("#FFA500")
                    else -> Color.parseColor("#39FF14")
                }
            )
            tvBaseBet.text = "PKR ${df.format(advice.baseBet)}"
            tvStrategicBet.text = "PKR ${df.format(advice.strategicBet)}"
            tvSafeCashout.text = "${df.format(advice.safeCashout)}x"
            tvStopLoss.text = "PKR ${df.format(advice.stopLoss)}"
            tvDailyTarget.text = "+PKR ${df.format(advice.dailyTarget)}"
        }

        viewModel.ocrStatus.observe(viewLifecycleOwner) { status ->
            tvOcrStatus.text = status
        }
    }

    private fun setupClickListeners() {
        btnActivateHud.setOnClickListener {
            val activity = requireActivity() as MainActivity
            if (activity.isHudRunning()) {
                activity.stopHud()
                btnActivateHud.text = "▶ ACTIVATE HUD"
            } else {
                activity.startHud()
                btnActivateHud.text = "⏹ STOP HUD"
            }
        }

        btnAuthOcr.setOnClickListener {
            val activity = requireActivity() as MainActivity
            if (activity.isOcrRunning()) {
                activity.stopOcr()
                btnAuthOcr.text = "AUTH OCR"
            } else {
                activity.startOcr()
                btnAuthOcr.text = "STOP OCR"
            }
        }

        btnClearAll.setOnClickListener {
            android.app.AlertDialog.Builder(requireContext())
                .setTitle("Clear All Data?")
                .setMessage("Sab rounds delete ho jayenge!")
                .setPositiveButton("Haan, Clear Karo") { _, _ -> viewModel.clearAll() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        btnAddManual.setOnClickListener {
            val text = etManualMult.text.toString().trim()
            val mult = text.toDoubleOrNull()
            if (mult != null && mult >= 1.0) {
                viewModel.addRound(mult, "MANUAL")
                etManualMult.setText("")
                Toast.makeText(requireContext(), "${mult}x added!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Valid multiplier enter karo (e.g. 1.85)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
