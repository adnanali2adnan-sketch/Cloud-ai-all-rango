package com.rangocompanion.ui.gemini

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.rangocompanion.R
import com.rangocompanion.viewmodel.MainViewModel

class GeminiFragment : Fragment() {

    private lateinit var viewModel: MainViewModel

    private lateinit var etApiKey: EditText
    private lateinit var btnShowHideKey: ImageButton
    private lateinit var btnSaveKey: MaterialButton
    private lateinit var etBalance: EditText
    private lateinit var btnUpdateBalance: MaterialButton
    private lateinit var etManualMult: EditText
    private lateinit var btnAddMult: MaterialButton
    private lateinit var tvGeminiResponse: TextView
    private lateinit var btnAnalyze: MaterialButton
    private lateinit var progressBar: ProgressBar
    private var isKeyVisible = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_gemini, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        etApiKey = view.findViewById(R.id.etApiKey)
        btnShowHideKey = view.findViewById(R.id.btnShowHideKey)
        btnSaveKey = view.findViewById(R.id.btnSaveKey)
        etBalance = view.findViewById(R.id.etBalance)
        btnUpdateBalance = view.findViewById(R.id.btnUpdateBalance)
        etManualMult = view.findViewById(R.id.etManualMult)
        btnAddMult = view.findViewById(R.id.btnAddMult)
        tvGeminiResponse = view.findViewById(R.id.tvGeminiResponse)
        btnAnalyze = view.findViewById(R.id.btnAnalyze)
        progressBar = view.findViewById(R.id.progressBar)

        // Show saved API key (masked)
        val savedKey = viewModel.getApiKey()
        if (savedKey.isNotBlank()) {
            etApiKey.setText(savedKey)
            etApiKey.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        // Show current balance
        etBalance.setText(viewModel.balance.value?.toString() ?: "0")

        btnShowHideKey.setOnClickListener {
            isKeyVisible = !isKeyVisible
            etApiKey.inputType = if (isKeyVisible) {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            etApiKey.setSelection(etApiKey.text.length)
        }

        btnSaveKey.setOnClickListener {
            val key = etApiKey.text.toString().trim()
            if (key.isNotBlank()) {
                viewModel.saveApiKey(key)
                Toast.makeText(requireContext(), "API Key saved securely!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "API key enter karo", Toast.LENGTH_SHORT).show()
            }
        }

        btnUpdateBalance.setOnClickListener {
            val bal = etBalance.text.toString().toDoubleOrNull()
            if (bal != null && bal >= 0) {
                viewModel.updateBalance(bal)
                Toast.makeText(requireContext(), "Balance updated!", Toast.LENGTH_SHORT).show()
            }
        }

        btnAddMult.setOnClickListener {
            val mult = etManualMult.text.toString().toDoubleOrNull()
            if (mult != null && mult >= 1.0) {
                viewModel.addRound(mult, "MANUAL")
                etManualMult.setText("")
                Toast.makeText(requireContext(), "${mult}x added!", Toast.LENGTH_SHORT).show()
            }
        }

        btnAnalyze.setOnClickListener {
            viewModel.requestGeminiAnalysis()
        }

        viewModel.geminiResponse.observe(viewLifecycleOwner) { response ->
            tvGeminiResponse.text = response
        }

        viewModel.isGeminiLoading.observe(viewLifecycleOwner) { loading ->
            progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            btnAnalyze.isEnabled = !loading
            btnAnalyze.text = if (loading) "Analyzing..." else "🔮 ANALYZE WITH GEMINI"
        }
    }
}
