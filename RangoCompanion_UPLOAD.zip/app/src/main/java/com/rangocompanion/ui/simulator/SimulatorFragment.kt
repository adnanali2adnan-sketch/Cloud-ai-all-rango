package com.rangocompanion.ui.simulator

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.rangocompanion.R
import com.rangocompanion.util.BankrollManager
import com.rangocompanion.viewmodel.MainViewModel
import java.text.DecimalFormat

class SimulatorFragment : Fragment() {

    private lateinit var viewModel: MainViewModel
    private val df = DecimalFormat("0.00")
    private var safetySteps = 5

    private lateinit var etBaseBet: EditText
    private lateinit var etTargetCap: EditText
    private lateinit var tvSteps: TextView
    private lateinit var btnMinus: Button
    private lateinit var btnPlus: Button
    private lateinit var tableLayout: TableLayout
    private lateinit var btnCalculate: MaterialButton

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_simulator, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        etBaseBet = view.findViewById(R.id.etBaseBet)
        etTargetCap = view.findViewById(R.id.etTargetCap)
        tvSteps = view.findViewById(R.id.tvSteps)
        btnMinus = view.findViewById(R.id.btnMinus)
        btnPlus = view.findViewById(R.id.btnPlus)
        tableLayout = view.findViewById(R.id.tableLayout)
        btnCalculate = view.findViewById(R.id.btnCalculate)

        updateStepsDisplay()

        btnMinus.setOnClickListener {
            if (safetySteps > 1) {
                safetySteps--
                updateStepsDisplay()
            }
        }

        btnPlus.setOnClickListener {
            if (safetySteps < 15) {
                safetySteps++
                updateStepsDisplay()
            }
        }

        btnCalculate.setOnClickListener {
            calculateMartingale()
        }

        // Auto calculate on first load
        calculateMartingale()
    }

    private fun updateStepsDisplay() {
        tvSteps.text = "$safetySteps Steps"
    }

    private fun calculateMartingale() {
        val baseBet = etBaseBet.text.toString().toDoubleOrNull() ?: 10.0
        val targetCap = etTargetCap.text.toString().toDoubleOrNull() ?: 2.0

        val steps = BankrollManager.martingaleSteps(baseBet, targetCap, safetySteps)

        // Clear table
        tableLayout.removeAllViews()

        // Header row
        val header = TableRow(requireContext()).apply {
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            addView(makeCell("LEVEL", Color.parseColor("#39FF14"), true))
            addView(makeCell("BET (PKR)", Color.parseColor("#39FF14"), true))
            addView(makeCell("COST", Color.parseColor("#39FF14"), true))
            addView(makeCell("NET WIN", Color.parseColor("#39FF14"), true))
        }
        tableLayout.addView(header)

        steps.forEachIndexed { index, step ->
            val row = TableRow(requireContext()).apply {
                setBackgroundColor(
                    if (index % 2 == 0) Color.parseColor("#0D0D0D")
                    else Color.parseColor("#141414")
                )
                addView(makeCell("${step.level}", Color.WHITE))
                addView(makeCell("${df.format(step.bet)}", Color.parseColor("#FFA500")))
                addView(makeCell("${df.format(step.totalCost)}", Color.parseColor("#FF6B6B")))
                addView(makeCell(
                    if (step.netWin >= 0) "+${df.format(step.netWin)}" else df.format(step.netWin),
                    if (step.netWin >= 0) Color.parseColor("#39FF14") else Color.RED
                ))
            }
            tableLayout.addView(row)
        }
    }

    private fun makeCell(text: String, color: Int, bold: Boolean = false): TextView {
        return TextView(requireContext()).apply {
            this.text = text
            setTextColor(color)
            textSize = 12f
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(16, 12, 16, 12)
        }
    }
}
