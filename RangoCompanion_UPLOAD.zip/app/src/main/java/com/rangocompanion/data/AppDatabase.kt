package com.rangocompanion.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ==================== ENTITY ====================
@Entity(tableName = "rounds")
data class RoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val multiplier: Double,
    val betSize: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "MANUAL"  // "MANUAL" or "OCR"
)

// ==================== DAO ====================
@Dao
interface RoundDao {
    @Query("SELECT * FROM rounds ORDER BY timestamp DESC")
    fun getAllRounds(): Flow<List<RoundEntity>>

    @Query("SELECT * FROM rounds ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentRounds(limit: Int = 50): List<RoundEntity>

    @Insert
    suspend fun insertRound(round: RoundEntity)

    @Delete
    suspend fun deleteRound(round: RoundEntity)

    @Query("DELETE FROM rounds")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM rounds")
    suspend fun getCount(): Int
}

// ==================== DATABASE ====================
@Database(entities = [RoundEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun roundDao(): RoundDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rango_companion_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
