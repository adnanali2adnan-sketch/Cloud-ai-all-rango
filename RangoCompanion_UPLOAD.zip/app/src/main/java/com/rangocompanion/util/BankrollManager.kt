package com.rangocompanion.util

data class BankrollAdvice(
    val baseBet: Double,
    val strategicBet: Double,
    val safeCashout: Double,
    val stopLoss: Double,
    val dailyTarget: Double,
    val riskScore: String,
    val riskColor: String  // "RED", "ORANGE", "GREEN"
)

object BankrollManager {

    fun calculate(balance: Double, trendResult: TrendResult): BankrollAdvice {
        // Base bet = 1% of balance
        val baseBet = (balance * 0.01).coerceAtLeast(1.0)

        // Strategic bet adjusted by trend
        val strategicBet = (baseBet * trendResult.betMultiplier).coerceAtLeast(1.0)

        // Safe cashout from trend
        val safeCashout = trendResult.cashoutAt

        // Stop loss = 15% of balance
        val stopLoss = (balance * 0.15).coerceAtLeast(10.0)

        // Daily target = 12% of balance
        val dailyTarget = (balance * 0.12).coerceAtLeast(5.0)

        // Risk score
        val riskScore: String
        val riskColor: String
        when {
            balance < 100 -> {
                riskScore = "EXTREME RISK"
                riskColor = "RED"
            }
            balance < 300 -> {
                riskScore = "HIGH RISK"
                riskColor = "RED"
            }
            trendResult.skipRound -> {
                riskScore = "EXTREME RISK"
                riskColor = "RED"
            }
            trendResult.betMultiplier < 0.5 -> {
                riskScore = "MED RISK"
                riskColor = "ORANGE"
            }
            else -> {
                riskScore = "LOW RISK"
                riskColor = "GREEN"
            }
        }

        return BankrollAdvice(
            baseBet = baseBet,
            strategicBet = strategicBet,
            safeCashout = safeCashout,
            stopLoss = stopLoss,
            dailyTarget = dailyTarget,
            riskScore = riskScore,
            riskColor = riskColor
        )
    }

    // Martingale calculator
    fun martingaleSteps(baseBet: Double, targetMultiplier: Double, steps: Int): List<MartingaleStep> {
        val result = mutableListOf<MartingaleStep>()
        var currentBet = baseBet
        var totalCost = 0.0

        for (i in 1..steps) {
            totalCost += currentBet
            val netWin = currentBet * targetMultiplier - totalCost
            result.add(
                MartingaleStep(
                    level = i,
                    bet = currentBet,
                    totalCost = totalCost,
                    netWin = netWin
                )
            )
            currentBet *= 2.0  // Double on loss
        }
        return result
    }
}

data class MartingaleStep(
    val level: Int,
    val bet: Double,
    val totalCost: Double,
    val netWin: Double
)
