package com.rangocompanion.util

import kotlin.math.abs

data class TrendResult(
    val trendLabel: String,       // "DOWNWARD TREND", "STEADY TREND", "HOT MOMENTUM"
    val trendEmoji: String,
    val confidence: Int,           // 0-100%
    val nextPred: Double,
    val cashoutAt: Double,
    val minSafe: Double,
    val betMultiplier: Double,     // e.g 0.5 = half base bet
    val trendDirection: String,    // "FALLING", "RISING", "MIXED", "STEADY"
    val streakLabel: String,       // "HOT", "COLD", "MIXED"
    val advice: String,
    val cashoutRangeMin: Double,
    val cashoutRangeMax: Double,
    val riskLevel: String,         // "LOW RISK", "MED RISK", "HIGH RISK", "EXTREME RISK"
    val skipRound: Boolean = false
)

object TrendAnalyzer {

    fun analyze(multipliers: List<Double>): TrendResult {
        if (multipliers.size < 3) {
            return TrendResult(
                trendLabel = "COLLECTING DATA",
                trendEmoji = "📊",
                confidence = 0,
                nextPred = 1.5,
                cashoutAt = 1.3,
                minSafe = 1.2,
                betMultiplier = 0.5,
                trendDirection = "UNKNOWN",
                streakLabel = "UNKNOWN",
                advice = "More rounds needed. Keep logging multipliers.",
                cashoutRangeMin = 1.2,
                cashoutRangeMax = 1.5,
                riskLevel = "MED RISK"
            )
        }

        val recent = multipliers.take(10)
        val avg = recent.average()
        val last = recent.first()
        val prev = if (recent.size > 1) recent[1] else last

        // Calculate streak type
        val highCount = recent.count { it >= 2.0 }
        val lowCount = recent.count { it < 1.3 }
        val streakLabel = when {
            highCount >= 4 -> "HOT"
            lowCount >= 4 -> "COLD"
            else -> "MIXED"
        }

        // Detect trend direction
        val recentAvg = recent.take(3).average()
        val olderAvg = if (recent.size >= 6) recent.drop(3).take(3).average() else avg
        val trendDirection = when {
            recentAvg > olderAvg * 1.15 -> "RISING"
            recentAvg < olderAvg * 0.85 -> "FALLING"
            else -> "MIXED"
        }

        // Confidence score
        val spreadList = recent.map { abs(it - avg) }
        val variance = spreadList.average()
        val confidence = when {
            variance < 0.5 -> 85
            variance < 1.0 -> 70
            variance < 2.0 -> 55
            else -> 40
        }.coerceIn(30, 95)

        // Predict next based on pattern
        val nextPred: Double
        val cashoutAt: Double
        val minSafe: Double
        val betMultiplier: Double
        val trendLabel: String
        val trendEmoji: String
        val advice: String
        val skipRound: Boolean

        when {
            // HOT MOMENTUM - high multipliers recently
            streakLabel == "HOT" && avg > 3.0 -> {
                trendLabel = "HOT MOMENTUM"
                trendEmoji = "🚀"
                nextPred = (avg * 0.7).coerceIn(1.3, 5.0)
                cashoutAt = 1.35
                minSafe = 1.15
                betMultiplier = 1.0
                advice = "Strong over-performing streak. High multiplier saturation. Auto Cashout set strictly at a safe 1.35x."
                skipRound = false
            }
            // DOWNWARD TREND - falling averages
            trendDirection == "FALLING" || (avg < 1.8 && last < prev) -> {
                trendLabel = "DOWNWARD TREND"
                trendEmoji = "📉"
                nextPred = (avg * 0.85).coerceIn(1.1, 3.0)
                cashoutAt = 1.3
                minSafe = 1.2
                betMultiplier = 0.5
                advice = "Trend declining from ${String.format("%.2f", olderAvg)}x. Reduce bet size. Early exit at 1.3x."
                skipRound = false
            }
            // COLD STREAK - many low multipliers
            streakLabel == "COLD" -> {
                trendLabel = "COLD STREAK"
                trendEmoji = "🥶"
                nextPred = 1.2
                cashoutAt = 1.2
                minSafe = 1.1
                betMultiplier = 0.25
                advice = "COLD zone — many early crashes. Minimum bet or SKIP this round."
                skipRound = true
            }
            // STEADY / STABLE
            trendDirection == "MIXED" && variance < 1.0 -> {
                trendLabel = "STEADY TREND"
                trendEmoji = "🚀"
                nextPred = (avg * 0.9).coerceIn(1.5, 6.0)
                cashoutAt = (avg * 0.7).coerceIn(1.3, 4.0)
                minSafe = 1.3
                betMultiplier = 1.0
                advice = "Stable pattern detected. Avg ${String.format("%.2f", avg)}x. Safe cashout at ${String.format("%.2f", cashoutAt)}x."
                skipRound = false
            }
            // RISING MOMENTUM
            trendDirection == "RISING" -> {
                trendLabel = "RISING TREND"
                trendEmoji = "📈"
                nextPred = (avg * 1.1).coerceIn(2.0, 10.0)
                cashoutAt = (avg * 0.8).coerceIn(1.5, 5.0)
                minSafe = 1.4
                betMultiplier = 1.5
                advice = "Upward momentum detected! Multipliers rising. Slightly increase bet but cashout at ${String.format("%.2f", cashoutAt)}x safely."
                skipRound = false
            }
            else -> {
                trendLabel = "STEADY TREND"
                trendEmoji = "🚀"
                nextPred = avg.coerceIn(1.3, 5.0)
                cashoutAt = (avg * 0.75).coerceIn(1.2, 3.0)
                minSafe = 1.2
                betMultiplier = 1.0
                advice = "No clear pattern. Play conservatively at ${String.format("%.2f", cashoutAt)}x."
                skipRound = false
            }
        }

        // Risk level
        val riskLevel = when {
            betMultiplier >= 1.5 -> "HIGH RISK"
            betMultiplier >= 1.0 && avg > 3.0 -> "MED RISK"
            betMultiplier <= 0.25 || skipRound -> "EXTREME RISK"
            betMultiplier <= 0.5 -> "MED RISK"
            else -> "LOW RISK"
        }

        return TrendResult(
            trendLabel = trendLabel,
            trendEmoji = trendEmoji,
            confidence = confidence,
            nextPred = nextPred,
            cashoutAt = cashoutAt,
            minSafe = minSafe,
            betMultiplier = betMultiplier,
            trendDirection = trendDirection,
            streakLabel = streakLabel,
            advice = advice,
            cashoutRangeMin = minSafe,
            cashoutRangeMax = cashoutAt * 1.2,
            riskLevel = riskLevel,
            skipRound = skipRound
        )
    }

    fun getWinRate(multipliers: List<Double>, threshold: Double = 2.0): Double {
        if (multipliers.isEmpty()) return 0.0
        return (multipliers.count { it >= threshold }.toDouble() / multipliers.size) * 100
    }

    fun getColdRate(multipliers: List<Double>, threshold: Double = 1.3): Double {
        if (multipliers.isEmpty()) return 0.0
        return (multipliers.count { it < threshold }.toDouble() / multipliers.size) * 100
    }

    fun getNetPL(multipliers: List<Double>, baseBet: Double, cashoutTarget: Double): Double {
        var total = 0.0
        for (m in multipliers) {
            total += if (m >= cashoutTarget) {
                baseBet * cashoutTarget - baseBet
            } else {
                -baseBet
            }
        }
        return total
    }
}
