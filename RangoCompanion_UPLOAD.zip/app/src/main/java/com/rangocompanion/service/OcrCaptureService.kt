package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.rangocompanion.R
import java.util.regex.Pattern

class OcrCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var isScanning = false
    private var scanInterval = 2000L  // scan every 2 seconds
    private var lastDetectedMultiplier = -1.0

    // Pattern to detect multiplier like "1.27x", "16.3x", "2.30x"
    private val multiplierPattern = Pattern.compile("""(\d{1,3}\.\d{1,2})[xX]""")
    // Also match "FLEW AWAY" with number pattern
    private val crashPattern = Pattern.compile("""(\d{1,3}\.\d{1,2})\s*[xX]""")

    companion object {
        const val ACTION_START = "START_OCR"
        const val ACTION_STOP = "STOP_OCR"
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_RESULT_DATA = "RESULT_DATA"
        const val BROADCAST_OCR_RESULT = "com.rangocompanion.OCR_RESULT"
        const val EXTRA_MULTIPLIER = "MULTIPLIER"
        private const val CHANNEL_ID = "ocr_channel"
        private const val TAG = "OcrCaptureService"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

                if (resultData != null) {
                    startForeground(2, buildNotification())
                    startCapture(resultCode, resultData)
                }
            }
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        isScanning = true
        startScanLoop()
        Log.d(TAG, "OCR Capture started")
    }

    private fun startScanLoop() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!isScanning) return
                captureAndOcr()
                handler.postDelayed(this, scanInterval)
            }
        }, scanInterval)
    }

    private fun captureAndOcr() {
        val image = imageReader?.acquireLatestImage() ?: return

        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            // Crop to top area where multiplier is shown (top 40% of screen)
            val croppedHeight = (bitmap.height * 0.4).toInt()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, croppedHeight)

            val inputImage = InputImage.fromBitmap(cropped, 0)

            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val detected = extractMultiplier(visionText.text)
                    if (detected != null && detected != lastDetectedMultiplier) {
                        // New multiplier detected!
                        lastDetectedMultiplier = detected
                        broadcastResult(detected)
                        Log.d(TAG, "OCR detected: ${detected}x")
                    }
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "OCR failed: ${e.message}")
                }

            bitmap.recycle()
            cropped.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "Capture error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun extractMultiplier(text: String): Double? {
        // Look for crash multiplier in text
        // Typical patterns: "2.30x", "FLEW AWAY! 11.97x", "Crashed at 1.27x"
        val lines = text.split("\n")

        for (line in lines) {
            val matcher = multiplierPattern.matcher(line)
            if (matcher.find()) {
                val value = matcher.group(1)?.toDoubleOrNull()
                if (value != null && value >= 1.0 && value <= 200.0) {
                    // Check if this is a final crash multiplier
                    // "FLEW AWAY" or static number means round ended
                    val isRoundEnd = line.contains("FLEW", ignoreCase = true) ||
                            line.contains("AWAY", ignoreCase = true) ||
                            line.contains("CRASH", ignoreCase = true)

                    if (isRoundEnd || value < 5.0) {
                        return value
                    }
                }
            }
        }
        return null
    }

    private fun broadcastResult(multiplier: Double) {
        val intent = Intent(BROADCAST_OCR_RESULT).apply {
            putExtra(EXTRA_MULTIPLIER, multiplier)
        }
        sendBroadcast(intent)
    }

    private fun stopCapture() {
        isScanning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        mediaProjection = null
        Log.d(TAG, "OCR Capture stopped")
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "OCR Screen Capture",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rango OCR Active")
            .setContentText("Scanning screen for crash multipliers...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
