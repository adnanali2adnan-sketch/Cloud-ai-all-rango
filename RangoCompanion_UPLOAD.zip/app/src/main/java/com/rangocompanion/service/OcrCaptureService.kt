package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.regex.Pattern

class OcrCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var isScanning = false
    private var lastDetectedMultiplier = -1.0
    private var lastDetectTime = 0L
    private val COOLDOWN_MS = 3000L // 3 sec cooldown between detections

    // Patterns for Rango/Aviator crash multipliers
    private val patterns = listOf(
        Pattern.compile("""(\d{1,3}[.,]\d{1,2})\s*[xX×]"""),           // 1.27x, 16.3x
        Pattern.compile("""[xX×]\s*(\d{1,3}[.,]\d{1,2})"""),           // x1.27
        Pattern.compile("""FLEW\s*AWAY[^\d]*(\d{1,3}[.,]\d{1,2})"""),  // FLEW AWAY 2.30
        Pattern.compile("""(\d{1,3}[.,]\d{1,2})\s*[xX×]\s*$"""),       // end of line
    )

    companion object {
        const val ACTION_START = "START_OCR"
        const val ACTION_STOP = "STOP_OCR"
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_RESULT_DATA = "RESULT_DATA"
        const val BROADCAST_OCR_RESULT = "com.rangocompanion.OCR_RESULT"
        const val EXTRA_MULTIPLIER = "MULTIPLIER"
        private const val CHANNEL_ID = "ocr_channel"
        private const val TAG = "OcrCaptureService"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (resultData != null) {
                    startForeground(2, buildNotification())
                    startCapture(resultCode, resultData)
                }
            }
            ACTION_STOP -> { stopCapture(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = pm.getMediaProjection(resultCode, resultData)

        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi

        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "RangoOCR", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        isScanning = true
        scheduleScan()
        Log.d(TAG, "OCR started")
    }

    private fun scheduleScan() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isScanning) {
                    captureAndOcr()
                    handler.postDelayed(this, 1500L) // scan every 1.5 sec
                }
            }
        }, 1500L)
    }

    private fun captureAndOcr() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bmp = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height, Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buffer)

            // Scan TOP 35% (where multiplier displays in Rango)
            val topH = (bmp.height * 0.35).toInt()
            val topCrop = Bitmap.createBitmap(bmp, 0, 0, bmp.width, topH)

            val inputImage = InputImage.fromBitmap(topCrop, 0)
            recognizer.process(inputImage)
                .addOnSuccessListener { result ->
                    val text = result.text
                    val detected = extractMultiplier(text)
                    val now = System.currentTimeMillis()

                    if (detected != null &&
                        detected != lastDetectedMultiplier &&
                        (now - lastDetectTime) > COOLDOWN_MS
                    ) {
                        lastDetectedMultiplier = detected
                        lastDetectTime = now
                        Log.d(TAG, "OCR detected: ${detected}x from: $text")
                        broadcastResult(detected)
                    }
                }
                .addOnFailureListener { Log.e(TAG, "OCR error: ${it.message}") }

            bmp.recycle()
            topCrop.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "Capture error: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun extractMultiplier(text: String): Double? {
        if (text.isBlank()) return null

        val lines = text.split("\n")
        val candidates = mutableListOf<Double>()

        for (line in lines) {
            val cleanLine = line.trim()
            for (pattern in patterns) {
                val matcher = pattern.matcher(cleanLine)
                while (matcher.find()) {
                    val raw = matcher.group(1)?.replace(",", ".") ?: continue
                    val value = raw.toDoubleOrNull() ?: continue
                    if (value >= 1.0 && value <= 500.0) {
                        candidates.add(value)
                    }
                }
            }
        }

        if (candidates.isEmpty()) return null

        // Prefer values that look like crash results
        // "FLEW AWAY" line or standalone large numbers
        val flewAwayLine = lines.find { it.contains("FLEW", ignoreCase = true) || it.contains("AWAY", ignoreCase = true) }
        if (flewAwayLine != null) {
            val matcher = Pattern.compile("""(\d{1,3}[.,]\d{1,2})""").matcher(flewAwayLine)
            if (matcher.find()) {
                return matcher.group(1)?.replace(",", ".")?.toDoubleOrNull()
            }
        }

        // Return the most prominent (first large) candidate
        return candidates.minOrNull()
    }

    private fun broadcastResult(multiplier: Double) {
        sendBroadcast(Intent(BROADCAST_OCR_RESULT).apply {
            putExtra(EXTRA_MULTIPLIER, multiplier)
        })
    }

    private fun stopCapture() {
        isScanning = false
        handler.removeCallbacksAndMessages(null)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        mediaProjection = null
    }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "OCR Screen Capture", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Rango OCR Active")
        .setContentText("Scanning for crash multipliers...")
        .setSmallIcon(android.R.drawable.ic_menu_camera)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
