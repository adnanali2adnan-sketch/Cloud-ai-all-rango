package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.InputType
import android.view.*
import android.view.WindowManager.LayoutParams
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingHudService : Service() {

    private lateinit var wm: WindowManager
    private var hudView: LinearLayout? = null
    private var expView: LinearLayout? = null
    private var hudParams: LayoutParams? = null
    private var expParams: LayoutParams? = null
    private var isExpanded = false
    private var aiEnabled = true
    private var aiExpanded = false
    private var activeTab = 0 // 0=OCR, 1=Manual
    private var isOcrRunning = false

    // State
    private var trend = "COLLECTING"; private var cashout = 1.3; private var next = 1.5
    private var minSafe = 1.2; private var betMult = "1.0x"; private var direction = "MIXED"
    private var streak = "MIXED"; private var advice = "Add rounds..."; private var aiTip = ""
    private var risk = "MED RISK"; private var lastMultStr = "—"; private var ocrStatus = "OCR offline"
    private val recentMults = mutableListOf<String>()

    companion object {
        const val ACTION_START_HUD = "START_HUD"; const val ACTION_STOP_HUD = "STOP_HUD"
        const val ACTION_UPDATE_HUD = "UPDATE_HUD"
        const val EXTRA_TREND = "TREND"; const val EXTRA_CASHOUT = "CASHOUT"
        const val EXTRA_NEXT = "NEXT"; const val EXTRA_MIN_SAFE = "MIN_SAFE"
        const val EXTRA_BET_MULT = "BET_MULT"; const val EXTRA_LAST_MULT = "LAST_MULT"
        const val EXTRA_DIRECTION = "DIRECTION"; const val EXTRA_STREAK = "STREAK"
        const val EXTRA_ADVICE = "ADVICE"; const val EXTRA_AI_TIP = "AI_TIP"
        const val EXTRA_RISK = "RISK"; const val EXTRA_OCR_STATUS = "OCR_STATUS"
        const val EXTRA_OCR_RUNNING = "OCR_RUNNING"
        const val BROADCAST_MANUAL_MULT = "com.rangocompanion.MANUAL_MULT"
        const val BROADCAST_OCR_TOGGLE = "com.rangocompanion.OCR_TOGGLE"
        const val EXTRA_MULTIPLIER = "MULTIPLIER"
        private const val CHANNEL_ID = "hud_channel"
    }

    override fun onCreate() { super.onCreate(); wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager; createChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_HUD -> { startForeground(1, buildNotif()); if (hudView == null) createPill() }
            ACTION_STOP_HUD -> { removeAll(); stopSelf() }
            ACTION_UPDATE_HUD -> {
                trend = intent.getStringExtra(EXTRA_TREND) ?: trend
                cashout = intent.getDoubleExtra(EXTRA_CASHOUT, cashout)
                next = intent.getDoubleExtra(EXTRA_NEXT, next)
                minSafe = intent.getDoubleExtra(EXTRA_MIN_SAFE, minSafe)
                betMult = intent.getStringExtra(EXTRA_BET_MULT) ?: betMult
                direction = intent.getStringExtra(EXTRA_DIRECTION) ?: direction
                streak = intent.getStringExtra(EXTRA_STREAK) ?: streak
                advice = intent.getStringExtra(EXTRA_ADVICE) ?: advice
                aiTip = intent.getStringExtra(EXTRA_AI_TIP) ?: aiTip
                risk = intent.getStringExtra(EXTRA_RISK) ?: risk
                ocrStatus = intent.getStringExtra(EXTRA_OCR_STATUS) ?: ocrStatus
                isOcrRunning = intent.getBooleanExtra(EXTRA_OCR_RUNNING, isOcrRunning)
                val lm = intent.getDoubleExtra(EXTRA_LAST_MULT, 0.0)
                if (lm > 0) {
                    lastMultStr = String.format("%.2f", lm) + "x"
                    val chip = lastMultStr
                    if (recentMults.isEmpty() || recentMults.first() != chip) {
                        recentMults.add(0, chip)
                        if (recentMults.size > 6) recentMults.removeLast()
                    }
                }
                updatePill()
                if (isExpanded) { removeExp(); showExp() }
            }
        }
        return START_STICKY
    }

    // ── COLLAPSED PILL ──────────────────────────────────────────────────
    private fun createPill() {
        val v = col(this).apply {
            background = bg("#DD080808", "#39FF14", 12f, 2f)
            setPadding(14, 10, 14, 10)
        }
        v.addView(tv("● HUD", "#39FF14", 8f, true).also { it.tag = "dot" })
        v.addView(tv("Last: $lastMultStr", "#FFFFFF", 10f, true).also { it.tag = "last" })
        v.addView(tv("↓", "#FFFF00", 8f).also { it.tag = "dir" })
        v.addView(tv(trend.take(10), "#FFA500", 7.5f, true).also { it.tag = "trnd" })
        v.addView(tv("Tap ▶", "#333333", 6.5f))
        hudParams = lp(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 200 }
        hudView = v; wm.addView(v, hudParams); setupPillTouch(v)
    }

    private fun updatePill() {
        val v = hudView ?: return
        for (i in 0 until v.childCount) {
            val c = v.getChildAt(i) as? TextView ?: continue
            when (c.tag) {
                "last" -> c.text = "Last: $lastMultStr"
                "dir" -> { c.text = if (direction=="FALLING") "↓" else if (direction=="RISING") "↑" else "→"; c.setTextColor(Color.parseColor(if(direction=="FALLING")"#FF4444" else if(direction=="RISING")"#39FF14" else "#FFFF00")) }
                "trnd" -> { c.text = trend.take(10); c.setTextColor(Color.parseColor(tColor())) }
            }
        }
    }

    // ── EXPANDED POPUP ───────────────────────────────────────────────────
    private fun showExp() {
        isExpanded = true
        val ctx = this
        val sw = resources.displayMetrics.widthPixels
        val root = col(ctx).apply {
            background = bg("#F5040404", "#39FF14", 10f, 1.5f)
            setPadding(9, 9, 9, 9)
        }

        // Drag handle bar
        root.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#39FF14"))
            layoutParams = LinearLayout.LayoutParams(32, 3).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = 6 }
        })

        // Header
        val hdr = row(ctx)
        hdr.addView(tv("🚀 PILOT", "#39FF14", 9f, true).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
        hdr.addView(tv("✕", "#FF4444", 12f).apply { setPadding(6,0,0,0); setOnClickListener { removeExp() } })
        root.addView(hdr); root.addView(space(ctx, 4))

        // Trend
        root.addView(tv(trend, tColor(), 10f, true).apply { setPadding(0,0,0,4) })

        // Row1: NEXT | CASHOUT | MIN OUT
        root.addView(threeBox(ctx, "NEXT" to fmt(next)+"x" to "#39FF14", "CASHOUT" to fmt(cashout)+"x" to "#39FF14", "MIN OUT" to fmt(minSafe)+"x" to "#FF4444"))
        root.addView(space(ctx, 3))
        // Row2: BET | TREND | STREAK
        root.addView(threeBox(ctx, "BET" to betMult to "#60A5FA", "TREND" to direction to "#FFA500", "STREAK" to streak to "#FFFFFF"))

        root.addView(tv(advice.take(55), "#555555", 6f).apply { setPadding(0,3,0,2); lineSpacingExtra = 1f })
        root.addView(tv("⚡ $risk", rColor(), 7.5f, true).apply { setPadding(0,0,0,3) })

        root.addView(div(ctx))

        // TABS
        val tabRow = row(ctx).apply { setPadding(0,0,0,4) }
        val tabOcr = tv("⚡ LIVE OCR", if(activeTab==0)"#000000" else "#444444", 7f, true).apply {
            background = bg(if(activeTab==0)"#FFA500" else "#111111","#222222",4f,0f)
            setPadding(8,4,8,4)
            layoutParams = LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f).apply { rightMargin=2 }
            setOnClickListener { activeTab=0; removeExp(); showExp() }
        }
        val tabMan = tv("⌨ MANUAL", if(activeTab==1)"#000000" else "#444444", 7f, true).apply {
            background = bg(if(activeTab==1)"#60A5FA" else "#111111","#222222",4f,0f)
            setPadding(8,4,8,4)
            layoutParams = LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)
            setOnClickListener { activeTab=1; removeExp(); showExp() }
        }
        tabRow.addView(tabOcr); tabRow.addView(tabMan); root.addView(tabRow)

        if (activeTab == 0) {
            // OCR TAB
            val statusDot = tv(if(isOcrRunning) "● scanning..." else "○ offline", if(isOcrRunning)"#39FF14" else "#555555", 7f)
            root.addView(statusDot)
            if (isOcrRunning && lastMultStr != "—") {
                val detBox = col(ctx).apply {
                    background = bg("#050f05","#1a3a1a",5f,1f)
                    setPadding(6,5,6,5)
                }
                detBox.addView(tv("CRASH DETECTED", "#444444", 5.5f))
                detBox.addView(tv(lastMultStr, "#39FF14", 14f, true))
                detBox.addView(tv("Auto logged ✓", "#555555", 5.5f))
                root.addView(detBox.apply { (layoutParams as? LinearLayout.LayoutParams)?.setMargins(0,3,0,3) ?: root.addView(detBox) })
            }
            val ocrBtn = tv(if(isOcrRunning)"■ STOP OCR" else "▶ START OCR", "#FFFFFF", 7f, true).apply {
                background = bg(if(isOcrRunning)"#CC2222" else "#228822","#000000",4f,0f)
                setPadding(0,5,0,5); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin=3 }
                setOnClickListener { sendBroadcast(Intent(BROADCAST_OCR_TOGGLE)) }
            }
            root.addView(ocrBtn)
        } else {
            // MANUAL TAB
            if (recentMults.isNotEmpty()) {
                root.addView(tv("Recently added:", "#444444", 5.5f).apply { setPadding(0,0,0,3) })
                val chipsRow = row(ctx).apply { setPadding(0,0,0,4) }
                recentMults.take(4).forEach { m ->
                    val v = m.replace("x","").toDoubleOrNull() ?: 1.0
                    chipsRow.addView(tv(m, if(v>=2.0)"#39FF14" else "#FF8888", 7f, true).apply {
                        background = bg(if(v>=2.0)"#0a1a0a" else "#1a0808","#000000",8f,0f)
                        setPadding(5,2,5,2)
                        (layoutParams as? LinearLayout.LayoutParams)?.rightMargin = 3
                    })
                }
                root.addView(chipsRow)
            }
            val entryRow = row(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
            val et = EditText(ctx).apply {
                hint = "1.85"; setHintTextColor(Color.parseColor("#333333"))
                setTextColor(Color.WHITE); textSize = 11f
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                background = bg("#0d0d0d","#2a2a2a",4f,1f)
                setPadding(8,5,8,5)
                layoutParams = LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f).apply { rightMargin=4 }
            }
            val addBtn = tv("✓ ADD","#060606",7.5f,true).apply {
                background = bg("#39FF14","#39FF14",5f,0f)
                setPadding(10,6,10,6)
                setOnClickListener {
                    val v2 = et.text.toString().toDoubleOrNull()
                    if (v2 != null && v2 >= 1.0) {
                        sendBroadcast(Intent(BROADCAST_MANUAL_MULT).apply { putExtra(EXTRA_MULTIPLIER, v2) })
                        et.setText(""); Toast.makeText(ctx,"${v2}x logged!",Toast.LENGTH_SHORT).show()
                    }
                }
            }
            entryRow.addView(et); entryRow.addView(addBtn); root.addView(entryRow)
        }

        root.addView(div(ctx))

        // AI TOGGLE ROW
        val aiToggleRow = row(ctx).apply {
            background = bg("#080d14","#141e2e",5f,1f)
            setPadding(7,5,7,5)
            gravity = Gravity.CENTER_VERTICAL
        }
        aiToggleRow.addView(tv("🌐 GEMINI AI","#60A5FA",7f,true).apply {
            layoutParams = LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)
        })
        aiToggleRow.addView(tv(if(aiEnabled)"ON ●" else "OFF ○", if(aiEnabled)"#39FF14" else "#333333", 6.5f, true).apply { setPadding(0,0,5,0) })
        val aiArrow = tv(if(aiExpanded)"▼" else "▶","#60A5FA",8f)
        aiToggleRow.addView(aiArrow)

        aiToggleRow.setOnClickListener {
            if (!aiExpanded) { aiExpanded = true; removeExp(); showExp() }
            else { aiExpanded = false; removeExp(); showExp() }
        }
        // Long press = enable/disable
        aiToggleRow.setOnLongClickListener { aiEnabled = !aiEnabled; removeExp(); showExp(); true }
        root.addView(aiToggleRow)

        // AI BODY (if expanded)
        if (aiExpanded && aiEnabled) {
            val aiBody = col(ctx).apply {
                background = bg("#050b12","#141e2e",0f,0f)
                setPadding(7,5,7,5)
            }
            val aiText = if (aiTip.isNotBlank()) aiTip else "Rounds add karo → analysis shuru ho"
            aiBody.addView(tv(aiText.take(80),"#8ab4f8",7f).apply { lineSpacingExtra = 2f })
            aiBody.addView(tv("↗ Full detail in app","#2a2a2a",5.5f).apply { setPadding(0,3,0,0) })
            root.addView(aiBody)
        }

        // Position expanded near pill
        val hx = hudParams?.x ?: 16; val hy = hudParams?.y ?: 200
        expParams = lp((sw * 0.52).toInt(), LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = hx; y = hy + 5
            flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        expView = root; wm.addView(root, expParams)

        // Make expanded draggable too
        setupExpTouch(root)
    }

    private fun removeExp() {
        expView?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        expView = null; isExpanded = false
    }

    // ── TOUCH HANDLERS ──────────────────────────────────────────────────
    private fun setupPillTouch(v: View) {
        var ix=0;var iy=0;var tx=0f;var ty=0f
        v.setOnTouchListener { _,e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { ix=hudParams?.x?:0; iy=hudParams?.y?:0; tx=e.rawX; ty=e.rawY; true }
                MotionEvent.ACTION_MOVE -> { hudParams?.x=ix+(e.rawX-tx).toInt(); hudParams?.y=iy+(e.rawY-ty).toInt(); hudView?.let{wm.updateViewLayout(it,hudParams)}; true }
                MotionEvent.ACTION_UP -> { if(Math.abs(e.rawX-tx)<10&&Math.abs(e.rawY-ty)<10){ if(isExpanded)removeExp() else showExp() }; true }
                else -> false
            }
        }
    }

    private fun setupExpTouch(v: View) {
        var ix=0;var iy=0;var tx=0f;var ty=0f
        v.setOnTouchListener { _,e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { ix=expParams?.x?:0; iy=expParams?.y?:0; tx=e.rawX; ty=e.rawY; true }
                MotionEvent.ACTION_MOVE -> { expParams?.x=ix+(e.rawX-tx).toInt(); expParams?.y=iy+(e.rawY-ty).toInt(); expView?.let{wm.updateViewLayout(it,expParams)}; true }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }
    }

    // ── HELPERS ──────────────────────────────────────────────────────────
    private fun tv(text:String,color:String,size:Float,bold:Boolean=false)=TextView(this).apply{this.text=text;setTextColor(Color.parseColor(color));textSize=size;if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD}
    private fun col(ctx:Context)=LinearLayout(ctx).apply{orientation=LinearLayout.VERTICAL}
    private fun row(ctx:Context)=LinearLayout(ctx).apply{orientation=LinearLayout.HORIZONTAL}
    private fun space(ctx:Context,h:Int)=View(ctx).apply{layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,h)}
    private fun div(ctx:Context)=View(ctx).apply{setBackgroundColor(Color.parseColor("#1a1a1a"));layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,1).apply{setMargins(0,4,0,4)}}
    private fun bg(fill:String,stroke:String,r:Float,sw:Float)=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=r;setColor(Color.parseColor(fill));if(sw>0)setStroke(sw.toInt(),Color.parseColor(stroke))}
    private fun lp(w:Int,h:Int)=LayoutParams(w,h,LayoutParams.TYPE_APPLICATION_OVERLAY,LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
    private fun fmt(d:Double)=String.format("%.2f",d)
    private fun tColor()=when{trend.contains("HOT")->"#39FF14";trend.contains("DOWN")||trend.contains("COLD")->"#FFA500";trend.contains("RISING")->"#60A5FA";else->"#FFFFFF"}
    private fun rColor()=when{risk.contains("EXTREME")||risk.contains("HIGH")->"#FF4444";risk.contains("MED")->"#FFA500";else->"#39FF14"}

    @Suppress("UNCHECKED_CAST")
    private fun threeBox(ctx:Context,vararg cols:Pair<Pair<String,String>,String>):LinearLayout{
        val r=row(ctx)
        cols.forEach{(lv,c)->
            val(l,vl)=lv
            val b=col(ctx).apply{background=bg("#0d0d0d","#000000",4f,0f);setPadding(5,4,5,4)}
            b.addView(tv(l,"#444444",5f))
            b.addView(tv(vl,c,8.5f,true))
            r.addView(b,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f).apply{rightMargin=2})
        }
        return r
    }

    private fun removeAll(){hudView?.let{if(it.isAttachedToWindow)wm.removeView(it)};expView?.let{if(it.isAttachedToWindow)wm.removeView(it)};hudView=null;expView=null}
    private fun createChannel(){NotificationChannel(CHANNEL_ID,"Floating HUD",NotificationManager.IMPORTANCE_LOW).also{getSystemService(NotificationManager::class.java).createNotificationChannel(it)}}
    private fun buildNotif()=NotificationCompat.Builder(this,CHANNEL_ID).setContentTitle("Rango HUD").setContentText("Tap HUD to expand").setSmallIcon(android.R.drawable.ic_dialog_info).setPriority(NotificationCompat.PRIORITY_LOW).build()
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onDestroy(){removeAll();super.onDestroy()}
}
