package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.InputType
import android.view.*
import android.view.WindowManager.LayoutParams
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingHudService : Service() {

    private lateinit var wm: WindowManager
    private var hudView: LinearLayout? = null
    private var expView: LinearLayout? = null
    private var hudParams: LayoutParams? = null
    private var expParams: LayoutParams? = null
    private var isExpanded = false
    private var aiEnabled = true
    private var aiExpanded = false
    private var activeTab = 0
    private var isOcrRunning = false

    private var trend = "COLLECTING"
    private var cashout = 1.3
    private var next = 1.5
    private var minSafe = 1.2
    private var betMult = "1.0x"
    private var direction = "MIXED"
    private var streak = "MIXED"
    private var advice = "Add rounds..."
    private var aiTip = ""
    private var risk = "MED RISK"
    private var lastMultStr = "—"
    private val recentMults = mutableListOf<String>()

    companion object {
        const val ACTION_START_HUD = "START_HUD"
        const val ACTION_STOP_HUD = "STOP_HUD"
        const val ACTION_UPDATE_HUD = "UPDATE_HUD"
        const val EXTRA_TREND = "TREND"
        const val EXTRA_CASHOUT = "CASHOUT"
        const val EXTRA_NEXT = "NEXT"
        const val EXTRA_MIN_SAFE = "MIN_SAFE"
        const val EXTRA_BET_MULT = "BET_MULT"
        const val EXTRA_LAST_MULT = "LAST_MULT"
        const val EXTRA_DIRECTION = "DIRECTION"
        const val EXTRA_STREAK = "STREAK"
        const val EXTRA_ADVICE = "ADVICE"
        const val EXTRA_AI_TIP = "AI_TIP"
        const val EXTRA_RISK = "RISK"
        const val EXTRA_OCR_STATUS = "OCR_STATUS"
        const val EXTRA_OCR_RUNNING = "OCR_RUNNING"
        const val BROADCAST_MANUAL_MULT = "com.rangocompanion.MANUAL_MULT"
        const val BROADCAST_OCR_TOGGLE = "com.rangocompanion.OCR_TOGGLE"
        const val EXTRA_MULTIPLIER = "MULTIPLIER"
        private const val CHANNEL_ID = "hud_channel"
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_HUD -> {
                startForeground(1, buildNotif())
                if (hudView == null) createPill()
            }
            ACTION_STOP_HUD -> {
                removeAll()
                stopSelf()
            }
            ACTION_UPDATE_HUD -> {
                trend = intent.getStringExtra(EXTRA_TREND) ?: trend
                cashout = intent.getDoubleExtra(EXTRA_CASHOUT, cashout)
                next = intent.getDoubleExtra(EXTRA_NEXT, next)
                minSafe = intent.getDoubleExtra(EXTRA_MIN_SAFE, minSafe)
                betMult = intent.getStringExtra(EXTRA_BET_MULT) ?: betMult
                direction = intent.getStringExtra(EXTRA_DIRECTION) ?: direction
                streak = intent.getStringExtra(EXTRA_STREAK) ?: streak
                advice = intent.getStringExtra(EXTRA_ADVICE) ?: advice
                aiTip = intent.getStringExtra(EXTRA_AI_TIP) ?: aiTip
                risk = intent.getStringExtra(EXTRA_RISK) ?: risk
                isOcrRunning = intent.getBooleanExtra(EXTRA_OCR_RUNNING, isOcrRunning)
                val lm = intent.getDoubleExtra(EXTRA_LAST_MULT, 0.0)
                if (lm > 0) {
                    lastMultStr = String.format("%.2f", lm) + "x"
                    if (recentMults.isEmpty() || recentMults.first() != lastMultStr) {
                        recentMults.add(0, lastMultStr)
                        if (recentMults.size > 6) recentMults.removeLast()
                    }
                }
                updatePill()
                if (isExpanded) {
                    removeExp()
                    showExp()
                }
            }
        }
        return START_STICKY
    }

    // ── COLLAPSED PILL ──────────────────────────────────────────────────
    private fun createPill() {
        val v = colLayout().apply {
            background = makeBg("#DD080808", "#39FF14", 12f, 2f)
            setPadding(14, 10, 14, 10)
        }
        v.addView(makeTv("● HUD", "#39FF14", 8f, true).also { it.tag = "dot" })
        v.addView(makeTv("Last: $lastMultStr", "#FFFFFF", 10f, true).also { it.tag = "last" })
        v.addView(makeTv("↓", "#FFFF00", 8f).also { it.tag = "dir" })
        v.addView(makeTv(trend.take(10), "#FFA500", 7.5f, true).also { it.tag = "trnd" })
        v.addView(makeTv("Tap ▶", "#333333", 6.5f))

        hudParams = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            it.x = 16
            it.y = 200
        }

        hudView = v
        wm.addView(v, hudParams)
        setupPillTouch(v)
    }

    private fun updatePill() {
        val v = hudView ?: return
        for (i in 0 until v.childCount) {
            val c = v.getChildAt(i) as? TextView ?: continue
            when (c.tag) {
                "last" -> c.text = "Last: $lastMultStr"
                "dir" -> {
                    c.text = if (direction == "FALLING") "↓" else if (direction == "RISING") "↑" else "→"
                    c.setTextColor(Color.parseColor(
                        if (direction == "FALLING") "#FF4444"
                        else if (direction == "RISING") "#39FF14"
                        else "#FFFF00"
                    ))
                }
                "trnd" -> {
                    c.text = trend.take(10)
                    c.setTextColor(Color.parseColor(trendColor()))
                }
            }
        }
    }

    // ── EXPANDED POPUP ───────────────────────────────────────────────────
    private fun showExp() {
        isExpanded = true
        val ctx = this
        val sw = resources.displayMetrics.widthPixels

        val root = colLayout().apply {
            background = makeBg("#F5040404", "#39FF14", 10f, 1.5f)
            setPadding(9, 9, 9, 9)
        }

        // Drag handle
        root.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#39FF14"))
            layoutParams = LinearLayout.LayoutParams(32, 3).also {
                it.gravity = Gravity.CENTER_HORIZONTAL
                it.bottomMargin = 6
            }
        })

        // Header
        val hdr = rowLayout()
        hdr.addView(makeTv("🚀 PILOT", "#39FF14", 9f, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        hdr.addView(makeTv("✕", "#FF4444", 12f).apply {
            setPadding(6, 0, 0, 0)
            setOnClickListener { removeExp() }
        })
        root.addView(hdr)
        root.addView(makeSpace(4))

        // Trend label
        root.addView(makeTv(trend, trendColor(), 10f, true).apply { setPadding(0, 0, 0, 4) })

        // Row1: NEXT | CASHOUT | MIN OUT
        val row1 = rowLayout()
        row1.addView(makeBox(ctx, "NEXT", fmt(next) + "x", "#39FF14"))
        row1.addView(makeBox(ctx, "CASHOUT", fmt(cashout) + "x", "#39FF14"))
        row1.addView(makeBox(ctx, "MIN OUT", fmt(minSafe) + "x", "#FF4444"))
        root.addView(row1)
        root.addView(makeSpace(3))

        // Row2: BET | TREND | STREAK
        val row2 = rowLayout()
        row2.addView(makeBox(ctx, "BET", betMult, "#60A5FA"))
        row2.addView(makeBox(ctx, "TREND", direction, "#FFA500"))
        row2.addView(makeBox(ctx, "STREAK", streak, "#FFFFFF"))
        root.addView(row2)

        root.addView(makeTv(advice.take(55), "#555555", 6f).apply { setPadding(0, 3, 0, 2) })
        root.addView(makeTv("⚡ $risk", riskColor(), 7.5f, true).apply { setPadding(0, 0, 0, 3) })
        root.addView(makeDivider())

        // TABS
        val tabRow = rowLayout().apply { setPadding(0, 0, 0, 4) }
        val tabOcr = makeTv("⚡ LIVE OCR", if (activeTab == 0) "#000000" else "#444444", 7f, true).apply {
            background = makeBg(if (activeTab == 0) "#FFA500" else "#111111", "#222222", 4f, 0f)
            setPadding(8, 4, 8, 4)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { it.rightMargin = 2 }
            setOnClickListener { activeTab = 0; removeExp(); showExp() }
        }
        val tabMan = makeTv("⌨ MANUAL", if (activeTab == 1) "#000000" else "#444444", 7f, true).apply {
            background = makeBg(if (activeTab == 1) "#60A5FA" else "#111111", "#222222", 4f, 0f)
            setPadding(8, 4, 8, 4)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { activeTab = 1; removeExp(); showExp() }
        }
        tabRow.addView(tabOcr)
        tabRow.addView(tabMan)
        root.addView(tabRow)

        // TAB CONTENT
        if (activeTab == 0) {
            // OCR tab
            root.addView(makeTv(
                if (isOcrRunning) "● scanning..." else "○ offline",
                if (isOcrRunning) "#39FF14" else "#555555",
                7f
            ))
            if (isOcrRunning && lastMultStr != "—") {
                val detBox = colLayout().apply {
                    background = makeBg("#050f05", "#1a3a1a", 5f, 1f)
                    setPadding(6, 5, 6, 5)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.setMargins(0, 3, 0, 3) }
                }
                detBox.addView(makeTv("CRASH DETECTED", "#444444", 5.5f))
                detBox.addView(makeTv(lastMultStr, "#39FF14", 14f, true))
                detBox.addView(makeTv("Auto logged ✓", "#555555", 5.5f))
                root.addView(detBox)
            }
            root.addView(makeTv(
                if (isOcrRunning) "■ STOP OCR" else "▶ START OCR",
                "#FFFFFF", 7f, true
            ).apply {
                background = makeBg(if (isOcrRunning) "#CC2222" else "#228822", "#000000", 4f, 0f)
                setPadding(0, 5, 0, 5)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = 3 }
                setOnClickListener { sendBroadcast(Intent(BROADCAST_OCR_TOGGLE)) }
            })
        } else {
            // Manual tab
            if (recentMults.isNotEmpty()) {
                root.addView(makeTv("Recently added:", "#444444", 5.5f).apply { setPadding(0, 0, 0, 3) })
                val chipsRow = rowLayout().apply { setPadding(0, 0, 0, 4) }
                recentMults.take(4).forEach { m ->
                    val v2 = m.replace("x", "").toDoubleOrNull() ?: 1.0
                    chipsRow.addView(makeTv(m, if (v2 >= 2.0) "#39FF14" else "#FF8888", 7f, true).apply {
                        background = makeBg(if (v2 >= 2.0) "#0a1a0a" else "#1a0808", "#000000", 8f, 0f)
                        setPadding(5, 2, 5, 2)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).also { it.rightMargin = 3 }
                    })
                }
                root.addView(chipsRow)
            }
            val entryRow = rowLayout().apply { gravity = Gravity.CENTER_VERTICAL }
            val et = EditText(ctx).apply {
                hint = "1.85"
                setHintTextColor(Color.parseColor("#333333"))
                setTextColor(Color.WHITE)
                textSize = 11f
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                background = makeBg("#0d0d0d", "#2a2a2a", 4f, 1f)
                setPadding(8, 5, 8, 5)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also {
                    it.rightMargin = 4
                }
            }
            val addBtn = makeTv("✓ ADD", "#060606", 7.5f, true).apply {
                background = makeBg("#39FF14", "#39FF14", 5f, 0f)
                setPadding(10, 6, 10, 6)
                setOnClickListener {
                    val v2 = et.text.toString().toDoubleOrNull()
                    if (v2 != null && v2 >= 1.0) {
                        sendBroadcast(Intent(BROADCAST_MANUAL_MULT).apply { putExtra(EXTRA_MULTIPLIER, v2) })
                        et.setText("")
                        Toast.makeText(ctx, "${v2}x logged!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            entryRow.addView(et)
            entryRow.addView(addBtn)
            root.addView(entryRow)
        }

        root.addView(makeDivider())

        // AI TOGGLE ROW
        val aiRow = rowLayout().apply {
            background = makeBg("#080d14", "#141e2e", 5f, 1f)
            setPadding(7, 5, 7, 5)
            gravity = Gravity.CENTER_VERTICAL
        }
        aiRow.addView(makeTv("🌐 AI", "#60A5FA", 7f, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        aiRow.addView(makeTv(
            if (aiEnabled) "ON ●" else "OFF ○",
            if (aiEnabled) "#39FF14" else "#333333",
            6.5f, true
        ).apply { setPadding(0, 0, 5, 0) })
        aiRow.addView(makeTv(if (aiExpanded) "▼" else "▶", "#60A5FA", 8f))
        aiRow.setOnClickListener {
            aiExpanded = !aiExpanded
            removeExp(); showExp()
        }
        aiRow.setOnLongClickListener {
            aiEnabled = !aiEnabled
            removeExp(); showExp()
            true
        }
        root.addView(aiRow)

        // AI BODY
        if (aiExpanded && aiEnabled) {
            val aiBody = colLayout().apply {
                background = makeBg("#050b12", "#141e2e", 0f, 0f)
                setPadding(7, 5, 7, 5)
            }
            val text = if (aiTip.isNotBlank()) aiTip.take(80) else "Rounds add karo → analysis shuru ho"
            aiBody.addView(makeTv(text, "#8ab4f8", 7f))
            aiBody.addView(makeTv("↗ Full detail in app", "#2a2a2a", 5.5f).apply { setPadding(0, 3, 0, 0) })
            root.addView(aiBody)
        }

        // Position near pill
        val hx = hudParams?.x ?: 16
        val hy = hudParams?.y ?: 200
        expParams = LayoutParams(
            (sw * 0.52).toInt(),
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            it.x = hx
            it.y = hy + 5
        }

        expView = root
        wm.addView(root, expParams)
        setupExpTouch(root)
    }

    private fun removeExp() {
        expView?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        expView = null
        isExpanded = false
    }

    // ── TOUCH: PILL ──────────────────────────────────────────────────────
    private fun setupPillTouch(v: View) {
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    val p = hudParams
                    if (p != null) { ix = p.x; iy = p.y }
                    tx = e.rawX; ty = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val p = hudParams
                    if (p != null) {
                        p.x = ix + (e.rawX - tx).toInt()
                        p.y = iy + (e.rawY - ty).toInt()
                        hudView?.let { wm.updateViewLayout(it, p) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (Math.abs(e.rawX - tx) < 10 && Math.abs(e.rawY - ty) < 10) {
                        if (isExpanded) removeExp() else showExp()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ── TOUCH: EXPANDED ──────────────────────────────────────────────────
    private fun setupExpTouch(v: View) {
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    val p = expParams
                    if (p != null) { ix = p.x; iy = p.y }
                    tx = e.rawX; ty = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val p = expParams
                    if (p != null) {
                        p.x = ix + (e.rawX - tx).toInt()
                        p.y = iy + (e.rawY - ty).toInt()
                        expView?.let { wm.updateViewLayout(it, p) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }
    }

    // ── VIEW HELPERS ─────────────────────────────────────────────────────
    private fun makeTv(text: String, color: String, size: Float, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor(color))
            textSize = size
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

    private fun colLayout() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun rowLayout() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private fun makeSpace(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h)
    }

    private fun makeDivider() = View(this).apply {
        setBackgroundColor(Color.parseColor("#1a1a1a"))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).also {
            it.setMargins(0, 4, 0, 4)
        }
    }

    private fun makeBg(fill: String, stroke: String, r: Float, sw: Float) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = r
            setColor(Color.parseColor(fill))
            if (sw > 0) setStroke(sw.toInt(), Color.parseColor(stroke))
        }

    private fun makeBox(ctx: Context, label: String, value: String, valueColor: String): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = makeBg("#0d0d0d", "#000000", 4f, 0f)
            setPadding(5, 4, 5, 4)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also {
                it.rightMargin = 2
            }
            addView(makeTv(label, "#444444", 5f))
            addView(makeTv(value, valueColor, 8.5f, true))
        }
    }

    private fun trendColor() = when {
        trend.contains("HOT") -> "#39FF14"
        trend.contains("DOWN") || trend.contains("COLD") -> "#FFA500"
        trend.contains("RISING") -> "#60A5FA"
        else -> "#FFFFFF"
    }

    private fun riskColor() = when {
        risk.contains("EXTREME") || risk.contains("HIGH") -> "#FF4444"
        risk.contains("MED") -> "#FFA500"
        else -> "#39FF14"
    }

    private fun fmt(d: Double) = String.format("%.2f", d)

    private fun removeAll() {
        hudView?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        expView?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        hudView = null; expView = null
    }

    private fun createChannel() {
        NotificationChannel(CHANNEL_ID, "Floating HUD", NotificationManager.IMPORTANCE_LOW)
            .also { getSystemService(NotificationManager::class.java).createNotificationChannel(it) }
    }

    private fun buildNotif() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Rango HUD")
        .setContentText("Tap HUD to expand")
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { removeAll(); super.onDestroy() }
}
