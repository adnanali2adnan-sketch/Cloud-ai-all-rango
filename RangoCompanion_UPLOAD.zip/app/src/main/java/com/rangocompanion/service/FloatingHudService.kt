package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.view.WindowManager.LayoutParams
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.rangocompanion.R

class FloatingHudService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var hudView: View
    private var params: LayoutParams? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isExpanded = false

    companion object {
        const val ACTION_START_HUD = "START_HUD"
        const val ACTION_STOP_HUD = "STOP_HUD"
        const val ACTION_UPDATE_HUD = "UPDATE_HUD"
        const val EXTRA_TREND = "TREND"
        const val EXTRA_CASHOUT = "CASHOUT"
        const val EXTRA_NEXT = "NEXT"
        const val EXTRA_LAST_MULT = "LAST_MULT"
        const val EXTRA_DIRECTION = "DIRECTION"
        const val EXTRA_AI_TIP = "AI_TIP"
        const val EXTRA_RISK = "RISK"
        private const val CHANNEL_ID = "hud_channel"
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_HUD -> {
                startForeground(1, buildNotification())
                if (!::hudView.isInitialized) {
                    createHudView()
                }
            }
            ACTION_STOP_HUD -> {
                removeHud()
                stopSelf()
            }
            ACTION_UPDATE_HUD -> {
                if (::hudView.isInitialized) {
                    val trend = intent.getStringExtra(EXTRA_TREND) ?: "—"
                    val cashout = intent.getDoubleExtra(EXTRA_CASHOUT, 1.3)
                    val next = intent.getDoubleExtra(EXTRA_NEXT, 1.5)
                    val lastMult = intent.getDoubleExtra(EXTRA_LAST_MULT, 0.0)
                    val direction = intent.getStringExtra(EXTRA_DIRECTION) ?: "MIXED"
                    val aiTip = intent.getStringExtra(EXTRA_AI_TIP) ?: ""
                    val risk = intent.getStringExtra(EXTRA_RISK) ?: "MED RISK"
                    updateHud(trend, cashout, next, lastMult, direction, aiTip, risk)
                }
            }
        }
        return START_STICKY
    }

    private fun createHudView() {
        // Collapsed HUD layout (small, non-intrusive)
        val collapsedLayout = """
            HUD view created programmatically
        """.trimIndent()

        // Create the HUD programmatically
        hudView = createHudViewProgrammatically()

        params = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 200
        }

        windowManager.addView(hudView, params)
        setupDragAndTap()
    }

    private fun createHudViewProgrammatically(): View {
        // Collapsed pill view
        val inflater = LayoutInflater.from(this)

        // We build the layout dynamically
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 16f
                setColor(Color.parseColor("#DD0D0D0D"))
                setStroke(2, Color.parseColor("#39FF14"))
            }
            setPadding(16, 12, 16, 12)
        }

        val tvLabel = TextView(this).apply {
            id = android.R.id.text1
            text = "● HUD"
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 10f
            tag = "LABEL"
        }

        val tvLast = TextView(this).apply {
            id = android.R.id.text2
            text = "Last: —"
            setTextColor(Color.WHITE)
            textSize = 11f
            tag = "LAST"
        }

        val tvDirection = TextView(this).apply {
            text = "↓"
            setTextColor(Color.YELLOW)
            textSize = 10f
            tag = "DIR"
        }

        val tvTrend = TextView(this).apply {
            text = "COLLECTING"
            setTextColor(Color.parseColor("#FFA500"))
            textSize = 9f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            tag = "TREND"
        }

        val tvTap = TextView(this).apply {
            text = "Tap"
            setTextColor(Color.GRAY)
            textSize = 8f
            tag = "TAP"
        }

        container.addView(tvLabel)
        container.addView(tvLast)
        container.addView(tvDirection)
        container.addView(tvTrend)
        container.addView(tvTap)

        return container
    }

    private fun updateHud(
        trend: String,
        cashout: Double,
        next: Double,
        lastMult: Double,
        direction: String,
        aiTip: String,
        risk: String
    ) {
        try {
            val container = hudView as android.widget.LinearLayout

            for (i in 0 until container.childCount) {
                val child = container.getChildAt(i)
                when ((child as? TextView)?.tag) {
                    "LAST" -> child.text = if (lastMult > 0) "Last: ${String.format("%.2f", lastMult)}x" else "Last: —"
                    "DIR" -> {
                        child.text = if (direction == "FALLING") "↓" else if (direction == "RISING") "↑" else "→"
                        child.setTextColor(
                            when (direction) {
                                "FALLING" -> Color.RED
                                "RISING" -> Color.GREEN
                                else -> Color.YELLOW
                            }
                        )
                    }
                    "TREND" -> child.text = trend.take(10)
                }
            }
        } catch (e: Exception) {
            // View might not be ready
        }
    }

    private fun setupDragAndTap() {
        hudView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params?.x ?: 0
                    initialY = params?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params?.x = initialX + (event.rawX - initialTouchX).toInt()
                    params?.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(hudView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (dx < 5 && dy < 5) {
                        // It's a tap — open main app
                        val intent = packageManager.getLaunchIntentForPackage(packageName)
                        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeHud() {
        if (::hudView.isInitialized && hudView.isAttachedToWindow) {
            windowManager.removeView(hudView)
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Floating HUD",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rango HUD Active")
            .setContentText("Floating overlay running. Tap to open app.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeHud()
        super.onDestroy()
    }
}
