package com.rangocompanion.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.InputType
import android.view.*
import android.view.WindowManager.LayoutParams
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingHudService : Service() {

    private lateinit var windowManager: WindowManager
    private var hudView: View? = null
    private var expandedView: View? = null
    private var params: LayoutParams? = null
    private var expandedParams: LayoutParams? = null
    private var isExpanded = false

    // Data
    private var currentTrend = "COLLECTING"
    private var currentCashout = 1.3
    private var currentNext = 1.5
    private var currentMinSafe = 1.2
    private var currentBetMult = "1.0x base"
    private var currentDirection = "MIXED"
    private var currentStreak = "MIXED"
    private var currentAdvice = "Add rounds to begin..."
    private var currentAiTip = ""
    private var currentRisk = "MED RISK"
    private var lastMult = 0.0
    private var lastMultStr = "—"

    companion object {
        const val ACTION_START_HUD = "START_HUD"
        const val ACTION_STOP_HUD = "STOP_HUD"
        const val ACTION_UPDATE_HUD = "UPDATE_HUD"
        const val EXTRA_TREND = "TREND"
        const val EXTRA_CASHOUT = "CASHOUT"
        const val EXTRA_NEXT = "NEXT"
        const val EXTRA_MIN_SAFE = "MIN_SAFE"
        const val EXTRA_BET_MULT = "BET_MULT"
        const val EXTRA_LAST_MULT = "LAST_MULT"
        const val EXTRA_DIRECTION = "DIRECTION"
        const val EXTRA_STREAK = "STREAK"
        const val EXTRA_ADVICE = "ADVICE"
        const val EXTRA_AI_TIP = "AI_TIP"
        const val EXTRA_RISK = "RISK"
        const val BROADCAST_MANUAL_MULT = "com.rangocompanion.MANUAL_MULT"
        const val EXTRA_MULTIPLIER = "MULTIPLIER"
        private const val CHANNEL_ID = "hud_channel"
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_HUD -> {
                startForeground(1, buildNotification())
                if (hudView == null) createCollapsedHud()
            }
            ACTION_STOP_HUD -> {
                removeAllViews()
                stopSelf()
            }
            ACTION_UPDATE_HUD -> {
                currentTrend = intent.getStringExtra(EXTRA_TREND) ?: currentTrend
                currentCashout = intent.getDoubleExtra(EXTRA_CASHOUT, currentCashout)
                currentNext = intent.getDoubleExtra(EXTRA_NEXT, currentNext)
                currentMinSafe = intent.getDoubleExtra(EXTRA_MIN_SAFE, currentMinSafe)
                currentBetMult = intent.getStringExtra(EXTRA_BET_MULT) ?: currentBetMult
                currentDirection = intent.getStringExtra(EXTRA_DIRECTION) ?: currentDirection
                currentStreak = intent.getStringExtra(EXTRA_STREAK) ?: currentStreak
                currentAdvice = intent.getStringExtra(EXTRA_ADVICE) ?: currentAdvice
                currentAiTip = intent.getStringExtra(EXTRA_AI_TIP) ?: currentAiTip
                currentRisk = intent.getStringExtra(EXTRA_RISK) ?: currentRisk
                val lm = intent.getDoubleExtra(EXTRA_LAST_MULT, 0.0)
                if (lm > 0) {
                    lastMult = lm
                    lastMultStr = String.format("%.2f", lm) + "x"
                }
                updateCollapsedHud()
                if (isExpanded) updateExpandedHud()
            }
        }
        return START_STICKY
    }

    private fun createCollapsedHud() {
        val ctx = this
        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(Color.parseColor("#DD0A0A0A"))
                setStroke(2, Color.parseColor("#39FF14"))
            }
            setPadding(20, 14, 20, 14)
        }

        val tvDot = TextView(ctx).apply {
            text = "● HUD"
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 10f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            tag = "DOT"
        }
        val tvLast = TextView(ctx).apply {
            text = "Last: $lastMultStr"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            tag = "LAST"
        }
        val tvDir = TextView(ctx).apply {
            text = "↓"
            setTextColor(Color.YELLOW)
            textSize = 10f
            tag = "DIR"
        }
        val tvTrend = TextView(ctx).apply {
            text = currentTrend.take(12)
            setTextColor(Color.parseColor("#FFA500"))
            textSize = 9f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            tag = "TREND"
        }
        val tvTap = TextView(ctx).apply {
            text = "Tap to expand"
            setTextColor(Color.parseColor("#666666"))
            textSize = 7f
        }

        container.addView(tvDot)
        container.addView(tvLast)
        container.addView(tvDir)
        container.addView(tvTrend)
        container.addView(tvTap)

        params = LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 200
        }

        hudView = container
        windowManager.addView(container, params)
        setupDrag(container)
    }

    private fun updateCollapsedHud() {
        val container = hudView as? LinearLayout ?: return
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i) as? TextView ?: continue
            when (child.tag) {
                "LAST" -> child.text = "Last: $lastMultStr"
                "DIR" -> {
                    child.text = when (currentDirection) { "FALLING" -> "↓"; "RISING" -> "↑"; else -> "→" }
                    child.setTextColor(when (currentDirection) { "FALLING" -> Color.RED; "RISING" -> Color.GREEN; else -> Color.YELLOW })
                }
                "TREND" -> {
                    child.text = currentTrend.take(12)
                    child.setTextColor(when {
                        currentTrend.contains("HOT") -> Color.parseColor("#39FF14")
                        currentTrend.contains("DOWN") || currentTrend.contains("COLD") -> Color.parseColor("#FFA500")
                        else -> Color.WHITE
                    })
                }
            }
        }
    }

    private fun showExpandedHud() {
        if (isExpanded) { removeExpandedHud(); return }
        isExpanded = true

        val ctx = this
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16f
                setColor(Color.parseColor("#F0060606"))
                setStroke(2, Color.parseColor("#39FF14"))
            }
            setPadding(24, 20, 24, 20)
        }

        // Header row
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val tvTitle = TextView(ctx).apply {
            text = "🚀 RANGO PILOT"
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnClose = TextView(ctx).apply {
            text = "✕"
            setTextColor(Color.RED)
            textSize = 16f
            setPadding(12, 0, 0, 0)
        }
        btnClose.setOnClickListener { removeExpandedHud() }
        header.addView(tvTitle)
        header.addView(btnClose)
        root.addView(header)

        // Trend label
        val tvTrend = TextView(ctx).apply {
            text = currentTrend
            setTextColor(when {
                currentTrend.contains("HOT") -> Color.parseColor("#39FF14")
                currentTrend.contains("DOWN") || currentTrend.contains("COLD") -> Color.parseColor("#FFA500")
                else -> Color.WHITE
            })
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 8)
        }
        root.addView(tvTrend)

        // 3 boxes: NEXT, CASHOUT, MIN OUT
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Triple("NEXT", String.format("%.2f", currentNext) + "x", "#39FF14"),
            Triple("CASHOUT", String.format("%.2f", currentCashout) + "x", "#39FF14"),
            Triple("MIN OUT", String.format("%.2f", currentMinSafe) + "x", "#FF4444")
        ).forEach { (label, value, color) ->
            val box = makeBox(ctx, label, value, color)
            row1.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0,0,4,0) })
        }
        root.addView(row1)

        val space1 = View(ctx).apply { minimumHeight = 8 }
        root.addView(space1)

        // 3 boxes: BET, TREND, STREAK
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Triple("BET", currentBetMult, "#60A5FA"),
            Triple("TREND", "↓ ${currentDirection}", "#FFA500"),
            Triple("STREAK", currentStreak, "#FFFFFF")
        ).forEach { (label, value, color) ->
            val box = makeBox(ctx, label, value, color)
            row2.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0,0,4,0) })
        }
        root.addView(row2)

        // Advice
        val tvAdvice = TextView(ctx).apply {
            text = currentAdvice
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 10f
            setPadding(0, 10, 0, 8)
        }
        root.addView(tvAdvice)

        // Risk
        val tvRisk = TextView(ctx).apply {
            text = "⚡ $currentRisk"
            setTextColor(when {
                currentRisk.contains("EXTREME") || currentRisk.contains("HIGH") -> Color.RED
                currentRisk.contains("MED") -> Color.parseColor("#FFA500")
                else -> Color.parseColor("#39FF14")
            })
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 8)
        }
        root.addView(tvRisk)

        // AI tip
        if (currentAiTip.isNotBlank()) {
            val tvAi = TextView(ctx).apply {
                text = "🌐 $currentAiTip"
                setTextColor(Color.parseColor("#FFA500"))
                textSize = 10f
                setPadding(0, 0, 0, 8)
            }
            root.addView(tvAi)
        }

        // Divider
        val div = View(ctx).apply {
            minimumHeight = 1
            setBackgroundColor(Color.parseColor("#333333"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply { setMargins(0, 8, 0, 8) }
        }
        root.addView(div)

        // Manual multiplier entry
        val tvManualLabel = TextView(ctx).apply {
            text = "⌨️ MANUAL ENTRY"
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 10f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 6)
        }
        root.addView(tvManualLabel)

        val entryRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val etMult = EditText(ctx).apply {
            hint = "e.g. 1.85"
            setHintTextColor(Color.parseColor("#555555"))
            setTextColor(Color.WHITE)
            textSize = 13f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 8f
                setColor(Color.parseColor("#1A1A1A"))
                setStroke(1, Color.parseColor("#333333"))
            }
            setPadding(16, 10, 16, 10)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0,0,8,0) }
        }
        val btnAdd = TextView(ctx).apply {
            text = "ADD"
            setTextColor(Color.parseColor("#060606"))
            setBackgroundColor(Color.parseColor("#39FF14"))
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(20, 12, 20, 12)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 10f
                setColor(Color.parseColor("#39FF14"))
            }
        }
        btnAdd.setOnClickListener {
            val val_ = etMult.text.toString().toDoubleOrNull()
            if (val_ != null && val_ >= 1.0) {
                val intent2 = Intent(BROADCAST_MANUAL_MULT).apply {
                    putExtra(EXTRA_MULTIPLIER, val_)
                }
                sendBroadcast(intent2)
                etMult.setText("")
                Toast.makeText(ctx, "${val_}x added!", Toast.LENGTH_SHORT).show()
            }
        }
        entryRow.addView(etMult)
        entryRow.addView(btnAdd)
        root.addView(entryRow)

        val screenWidth = resources.displayMetrics.widthPixels
        expandedParams = LayoutParams(
            (screenWidth * 0.85).toInt(),
            LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        expandedView = root
        windowManager.addView(root, expandedParams)
    }

    private fun makeBox(ctx: Context, label: String, value: String, valueColor: String): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 8f
                setColor(Color.parseColor("#111111"))
            }
            setPadding(10, 8, 10, 8)
            addView(TextView(ctx).apply {
                text = label; setTextColor(Color.parseColor("#888888")); textSize = 8f
            })
            addView(TextView(ctx).apply {
                text = value; setTextColor(Color.parseColor(valueColor)); textSize = 13f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            })
        }
    }

    private fun updateExpandedHud() {
        removeExpandedHud()
        if (isExpanded) showExpandedHud()
    }

    private fun removeExpandedHud() {
        expandedView?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
            expandedView = null
        }
        isExpanded = false
    }

    private fun setupDrag(view: View) {
        var iX = 0; var iY = 0; var iTX = 0f; var iTY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params?.x ?: 0; iY = params?.y ?: 0
                    iTX = event.rawX; iTY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params?.x = iX + (event.rawX - iTX).toInt()
                    params?.y = iY + (event.rawY - iTY).toInt()
                    hudView?.let { windowManager.updateViewLayout(it, params) }; true
                }
                MotionEvent.ACTION_UP -> {
                    if (Math.abs(event.rawX - iTX) < 8 && Math.abs(event.rawY - iTY) < 8) {
                        showExpandedHud() // TAP = show expanded, NOT open app
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeAllViews() {
        hudView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        expandedView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        hudView = null; expandedView = null
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Floating HUD", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rango HUD Active")
            .setContentText("Tap HUD to expand predictions")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() { removeAllViews(); super.onDestroy() }
}
