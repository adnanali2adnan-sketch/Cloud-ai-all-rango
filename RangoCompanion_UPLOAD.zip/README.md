# Rango Companion - AI Strategy Cockpit
## Full Android Project - Kotlin

### Project Structure:
```
RangoCompanion/
├── app/
│   ├── src/main/
│   │   ├── java/com/rangocompanion/
│   │   │   ├── MainActivity.kt
│   │   │   ├── ui/
│   │   │   │   ├── dashboard/DashboardFragment.kt
│   │   │   │   ├── gemini/GeminiFragment.kt
│   │   │   │   └── simulator/SimulatorFragment.kt
│   │   │   ├── service/
│   │   │   │   ├── FloatingHudService.kt
│   │   │   │   └── OcrCaptureService.kt
│   │   │   ├── data/
│   │   │   │   ├── AppDatabase.kt
│   │   │   │   ├── RoundEntity.kt
│   │   │   │   └── RoundDao.kt
│   │   │   ├── viewmodel/
│   │   │   │   └── MainViewModel.kt
│   │   │   ├── api/
│   │   │   │   └── GeminiApiClient.kt
│   │   │   └── util/
│   │   │       ├── TrendAnalyzer.kt
│   │   │       └── BankrollManager.kt
│   │   ├── res/layout/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── .github/workflows/build.yml
```

### GitHub APK Build:
Push to main branch → GitHub Actions automatically builds APK → Download from Actions tab
