# 🚀 Rango Companion v2.0 - Setup Guide

## ⚡ GitHub Se APK Build Karo (5 Steps)

1. **GitHub pe new repo banao** → "RangoCompanion"
2. **Ye saari files upload karo** (folder structure same rakhna)
3. **Push karo to main branch**
4. **GitHub → Actions tab** → "Build APK" workflow chale ga automatically
5. **Actions → Your Run → Artifacts** → APK download karo!

---

## 📁 Files Jo AI Studio Mein Generate Karni Hain

Kuch XML layouts AI Studio se generate karo:

**Paste this prompt in AI Studio:**

```
Generate these Android XML layout files for a dark-themed crash game companion app called "Rango Companion":

1. fragment_dashboard.xml - Contains:
   - HorizontalScrollView with ChipGroup (id: chipGroupMultipliers) at top
   - CardView with: tvTrendLabel, tvConfidence (%), tvNextPred, tvCashoutAt, tvMinSafe, tvBetMult, tvTrendDir, tvStreak, tvAdvice TextViews
   - 3 stat cards: tvWinRate, tvColdRate, tvNetPL
   - CardView "COCKPIT HUD": btnActivateHud (MaterialButton green), btnAuthOcr (MaterialButton outlined)
   - CardView "SMART BANKROLL": tvBalance, tvRiskScore, tvBaseBet, tvStrategicBet, tvSafeCashout, tvStopLoss, tvDailyTarget
   - tvOcrStatus TextView
   - LinearLayout with etManualMult EditText + btnAddManual Button
   - btnClearAll ImageButton (trash icon, top right)

2. fragment_gemini.xml - Contains:
   - tvTitle "Gemini AI Cockpit"
   - CardView GEMINI API KEY: etApiKey, btnShowHideKey (eye icon), btnSaveKey (green button)
   - CardView WALLET BALANCE: etBalance (PKR prefix), btnUpdateBalance (blue button)
   - CardView MANUAL ROUND ENTRY: etManualMult, btnAddMult
   - progressBar (horizontal)
   - tvGeminiResponse (yellow text, dark card)
   - btnAnalyze (green large button)

3. fragment_simulator.xml - Contains:
   - Title "MARTINGALE STEPS CALCULATOR"
   - CardView SIMULATION PARAMETERS: etBaseBet, etTargetCap
   - Stepper row: btnMinus, tvSteps, btnPlus
   - TableLayout (id: tableLayout) for martingale table
   - btnCalculate (green button)

Style: Background #060606, Cards #0D0D0D, Green accent #39FF14, Orange #FFA500
Use Material Design components. Dark theme throughout.
```

---

## 🆕 Naye Features (Jo Tumhari App Mein Nahi The)

### 1. **Auto Gemini Trigger on OCR**
Jaise hi OCR ek multiplier detect kare → Gemini automatically call hota hai. Manual button daba ne ki zaroorat nahi!

### 2. **Confidence Score**
Har trend prediction ke saath % confidence show hoti hai. Low variance = high confidence.

### 3. **Net P/L Tracker**
Simulated profit/loss track hota hai based on rounds logged. Real bankroll performance dikh ti hai.

### 4. **5 Trend Types** (vs original 2-3)
- DOWNWARD TREND 📉
- HOT MOMENTUM 🚀
- COLD STREAK 🥶
- RISING TREND 📈
- STEADY TREND 🎯

### 5. **OCR Source Tagging**
Har round "MANUAL" ya "OCR" se mark hota hai. Stats mein alag dikhai de sakte hain.

### 6. **Smart Cashout Range Bar**
Min safe → Max cashout range visually show hoti hai (progress bar style).

### 7. **Round Streak Colors**
Chips mein: Purple for 5x+, Green for 2x+, Red for under 1.3x, Orange border for latest.

---

## 🔧 OCR Accuracy Tips

OCR ML Kit use karta hai — accuracy improve karne ke liye:
- Rango game ka font bada ho to better detection
- Screen brightness maximum rakhna
- App scans every 2 seconds (OcrCaptureService.kt mein `scanInterval` badha sakte ho)
- Sirf top 40% of screen scan hoti hai (multiplier wahan hota hai)
- Pattern: `(\d{1,3}\.\d{1,2})[xX]` — 1.27x, 16.3x, 2.30x sab detect karta hai

---

## ⚠️ Important Permissions
- SYSTEM_ALERT_WINDOW → Floating HUD ke liye
- FOREGROUND_SERVICE_MEDIA_PROJECTION → Screen OCR ke liye
- INTERNET → Gemini API ke liye
- POST_NOTIFICATIONS → Foreground service ke liye

Pehli baar app open karo → sab permissions allow karo.
